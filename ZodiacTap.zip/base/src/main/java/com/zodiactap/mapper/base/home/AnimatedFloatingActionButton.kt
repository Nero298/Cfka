package com.zodiactap.mapper.base.home

import androidx.compose.animation.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.zodiactap.mapper.base.compose.KeyMapperTheme
import com.zodiactap.mapper.base.compose.LocalCustomColorsPalette
import com.zodiactap.mapper.base.utils.ui.compose.CollapsableFloatingActionButton

@Composable
fun AnimatedFloatingActionButton(
    modifier: Modifier = Modifier,
    pulse: Boolean,
    showFabText: Boolean,
    text: String,
    onClick: () -> Unit,
) {
    val defaultColor = MaterialTheme.colorScheme.primaryContainer
    val pulseColor = LocalCustomColorsPalette.current.primaryContainerDarker

    val animatedPulseColor = remember { Animatable(defaultColor) }
    var finishedAnimation by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(pulse) {
        if (pulse && !finishedAnimation) {
            repeat(10) {
                animatedPulseColor.animateTo(pulseColor, tween(700))
                animatedPulseColor.animateTo(defaultColor, tween(700))
            }

            finishedAnimation = true
        }
    }

    CollapsableFloatingActionButton(
        modifier = modifier,
        onClick = {
            finishedAnimation = true
            onClick()
        },
        showText = showFabText,
        text = text,
        containerColor = animatedPulseColor.value,
    )
}

@Preview
@Composable
private fun PreviewAnimatedFloatingActionButton() {
    KeyMapperTheme {
        AnimatedFloatingActionButton(
            pulse = false,
            showFabText = true,
            text = "New Key Map",
            onClick = {},
        )
    }
}

@Preview
@Composable
private fun PreviewAnimatedFloatingActionButtonPulsing() {
    KeyMapperTheme {
        AnimatedFloatingActionButton(
            pulse = true,
            showFabText = true,
            text = "New Key Map",
            onClick = {},
        )
    }
}
