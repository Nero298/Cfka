package com.zodiactap.mapper.base.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.FindInPage
import androidx.compose.material.icons.outlined.Gamepad
import androidx.compose.material.icons.outlined.OfflineBolt
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zodiactap.mapper.base.R
import com.zodiactap.mapper.base.backup.BackupUtils
import com.zodiactap.mapper.base.compose.KeyMapperTheme
import com.zodiactap.mapper.base.utils.ui.compose.KeyMapperSegmentedButtonRow
import com.zodiactap.mapper.base.utils.ui.compose.OptionPageButton
import com.zodiactap.mapper.base.utils.ui.compose.OptionsHeaderRow
import com.zodiactap.mapper.base.utils.ui.compose.RadioButtonText
import com.zodiactap.mapper.base.utils.ui.compose.SwitchPreferenceCompose
import com.zodiactap.mapper.base.utils.ui.compose.icons.FolderManaged
import com.zodiactap.mapper.base.utils.ui.compose.icons.KeyMapperIcons
import com.zodiactap.mapper.base.utils.ui.compose.icons.WandStars
import com.zodiactap.mapper.common.utils.BuildUtils
import com.zodiactap.mapper.system.files.FileUtils
import kotlinx.coroutines.launch

private val isAutoSwitchImeSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

@Composable
fun SettingsScreen(modifier: Modifier = Modifier, viewModel: SettingsViewModel) {
    val state by viewModel.mainScreenState.collectAsStateWithLifecycle()
    val snackbarHostState = SnackbarHostState()
    var showAutomaticBackupDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val automaticBackupLocationChooser =
        rememberLauncherForActivityResult(CreateDocument(FileUtils.MIME_TYPE_ZIP)) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            viewModel.setAutomaticBackupLocation(uri.toString())

            val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION

            context.contentResolver.takePersistableUriPermission(uri, takeFlags)
        }

    if (showAutomaticBackupDialog) {
        val activityNotFoundText =
            stringResource(R.string.dialog_message_no_app_found_to_create_file)

        AlertDialog(
            onDismissRequest = { showAutomaticBackupDialog = false },
            title = { Text(stringResource(R.string.dialog_title_change_location_or_disable)) },
            text = { Text(stringResource(R.string.dialog_message_change_location_or_disable)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showAutomaticBackupDialog = false

                        try {
                            automaticBackupLocationChooser.launch(
                                BackupUtils.DEFAULT_AUTOMATIC_BACKUP_NAME,
                            )
                        } catch (e: ActivityNotFoundException) {
                            scope.launch {
                                snackbarHostState.showSnackbar(activityNotFoundText)
                            }
                        }
                    },
                ) {
                    Text(stringResource(R.string.pos_change_location))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showAutomaticBackupDialog = false
                        viewModel.disableAutomaticBackup()
                    },
                ) {
                    Text(stringResource(R.string.neg_turn_off))
                }
            },
        )
    }

    SettingsScreen(
        modifier,
        onBackClick = viewModel::onBackClick,
        viewModel::onResetAllSettingsClick,
        snackbarHostState = snackbarHostState,
    ) {
        Content(
            state = state,
            onThemeSelected = viewModel::onThemeSelected,
            onPauseResumeNotificationClick = viewModel::onPauseResumeNotificationClick,
            onDefaultOptionsClick = viewModel::onDefaultOptionsClick,
            onExpertModeClick = viewModel::onExpertModeClick,
            onAutomaticChangeImeClick = viewModel::onAutomaticChangeImeClick,
            onForceVibrateToggled = viewModel::onForceVibrateToggled,
            onLoggingToggled = viewModel::onLoggingToggled,
            onViewLogClick = viewModel::onViewLogClick,
            onHideHomeScreenAlertsToggled = viewModel::onHideHomeScreenAlertsToggled,
            onShowDeviceDescriptorsToggled = viewModel::onShowDeviceDescriptorsToggled,
            onAutomaticBackupClick = {
                if (state.autoBackupLocation.isNullOrBlank()) {
                    automaticBackupLocationChooser.launch(BackupUtils.DEFAULT_AUTOMATIC_BACKUP_NAME)
                } else {
                    showAutomaticBackupDialog = true
                }
            },
            onShareLogcatClick = viewModel::onShareLogcatClick,
            onKeyEventActionMethodSelected = viewModel::onKeyEventActionMethodSelected,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    modifier: Modifier = Modifier,
    onBackClick: () -> Unit = {},
    onResetClick: () -> Unit = {},
    snackbarHostState: SnackbarHostState = SnackbarHostState(),
    content: @Composable () -> Unit,
) {
    Scaffold(
        modifier = modifier.displayCutoutPadding(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.action_settings)) },
                actions = {
                    OutlinedButton(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        onClick = onResetClick,
                    ) {
                        Text(stringResource(R.string.settings_reset_app_bar_button))
                    }
                },
            )
        },
        bottomBar = {
            BottomAppBar {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(R.string.action_go_back),
                    )
                }
            }
        },
    ) { innerPadding ->
        val layoutDirection = LocalLayoutDirection.current
        val startPadding = innerPadding.calculateStartPadding(layoutDirection)
        val endPadding = innerPadding.calculateEndPadding(layoutDirection)

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding(),
                    start = startPadding,
                    end = endPadding,
                ),
        ) {
            content()
        }
    }
}

@Composable
private fun Content(
    modifier: Modifier = Modifier,
    state: MainSettingsState,
    onThemeSelected: (Theme) -> Unit = { },
    onPauseResumeNotificationClick: () -> Unit = { },
    onDefaultOptionsClick: () -> Unit = { },
    onAutomaticBackupClick: () -> Unit = { },
    onExpertModeClick: () -> Unit = { },
    onAutomaticChangeImeClick: () -> Unit = { },
    onForceVibrateToggled: (Boolean) -> Unit = { },
    onLoggingToggled: (Boolean) -> Unit = { },
    onViewLogClick: () -> Unit = { },
    onShareLogcatClick: () -> Unit = { },
    onHideHomeScreenAlertsToggled: (Boolean) -> Unit = { },
    onShowDeviceDescriptorsToggled: (Boolean) -> Unit = { },
    onKeyEventActionMethodSelected: (isExpertModeSelected: Boolean) -> Unit = {},
) {
    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        OptionsHeaderRow(
            modifier = Modifier.fillMaxWidth(),
            icon = KeyMapperIcons.WandStars,
            text = stringResource(R.string.settings_section_customize_experience_title),
        )

        Text(
            text = stringResource(R.string.title_pref_dark_theme),
            style = MaterialTheme.typography.bodyLarge,
        )

        val buttonStates: List<Pair<Theme, String>> = listOf(
            Theme.AUTO to stringResource(R.string.theme_system),
            Theme.LIGHT to stringResource(R.string.theme_light),
            Theme.DARK to stringResource(R.string.theme_dark),
        )

        KeyMapperSegmentedButtonRow(
            modifier = Modifier.fillMaxWidth(),
            buttonStates,
            state.theme,
            onStateSelected = onThemeSelected,
        )

        OptionPageButton(
            title = stringResource(R.string.title_pref_show_toggle_keymaps_notification),
            text = stringResource(R.string.summary_pref_show_toggle_keymaps_notification),
            icon = Icons.Rounded.PlayCircleOutline,
            onClick = onPauseResumeNotificationClick,
        )

        SwitchPreferenceCompose(
            title = stringResource(R.string.title_pref_hide_home_screen_alerts),
            text = stringResource(R.string.summary_pref_hide_home_screen_alerts),
            icon = Icons.Rounded.VisibilityOff,
            isChecked = state.hideHomeScreenAlerts,
            onCheckedChange = onHideHomeScreenAlertsToggled,
        )

        OptionsHeaderRow(
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Outlined.Gamepad,
            text = stringResource(R.string.settings_section_key_maps_title),
        )

        OptionPageButton(
            title = stringResource(R.string.title_pref_default_options),
            text = stringResource(R.string.summary_pref_default_options),
            icon = Icons.Rounded.Tune,
            onClick = onDefaultOptionsClick,
        )

        SwitchPreferenceCompose(
            title = stringResource(R.string.title_pref_force_vibrate),
            text = stringResource(R.string.summary_pref_force_vibrate),
            icon = Icons.Rounded.Vibration,
            isChecked = state.forceVibrate,
            onCheckedChange = onForceVibrateToggled,
        )

        SwitchPreferenceCompose(
            title = stringResource(R.string.title_pref_show_device_descriptors),
            text = stringResource(R.string.summary_pref_show_device_descriptors),
            icon = Icons.Rounded.Devices,
            isChecked = state.showDeviceDescriptors,
            onCheckedChange = onShowDeviceDescriptorsToggled,
        )

        OptionsHeaderRow(
            modifier = Modifier.fillMaxWidth(),
            icon = KeyMapperIcons.FolderManaged,
            text = stringResource(R.string.settings_section_data_management_title),
        )

        OptionPageButton(
            title = if (state.autoBackupLocation == null) {
                stringResource(R.string.title_pref_automatic_backup_location_disabled)
            } else {
                stringResource(R.string.title_pref_automatic_backup_location_enabled)
            },
            text = state.autoBackupLocation
                ?: stringResource(R.string.summary_pref_automatic_backup_location_disabled),
            icon = Icons.Rounded.Tune,
            onClick = onAutomaticBackupClick,
        )

        OptionsHeaderRow(
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Rounded.Construction,
            text = stringResource(R.string.settings_section_power_user_title),
        )

        KeyEventActionMethodRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            isExpertModeSelected = state.keyEventActionsUseSystemBridge,
            onSelected = onKeyEventActionMethodSelected,
        )

        OptionPageButton(
            title = stringResource(R.string.title_pref_expert_mode),
            text = stringResource(R.string.summary_pref_expert_mode),
            icon = Icons.Outlined.OfflineBolt,
            onClick = onExpertModeClick,
        )

        OptionPageButton(
            title = stringResource(R.string.title_pref_automatically_change_ime),
            text = if (isAutoSwitchImeSupported) {
                stringResource(R.string.summary_pref_automatically_change_ime)
            } else {
                stringResource(
                    R.string.error_sdk_version_too_low,
                    BuildUtils.getSdkVersionName(Build.VERSION_CODES.R),
                )
            },
            icon = Icons.Rounded.Keyboard,
            onClick = onAutomaticChangeImeClick,
            enabled = isAutoSwitchImeSupported,
        )

        OptionsHeaderRow(
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Rounded.Code,
            text = stringResource(R.string.settings_section_debugging_title),
        )

        SwitchPreferenceCompose(
            title = stringResource(R.string.title_pref_toggle_logging),
            text = stringResource(R.string.summary_pref_toggle_logging),
            icon = Icons.Outlined.BugReport,
            isChecked = state.loggingEnabled,
            onCheckedChange = onLoggingToggled,
        )

        OptionPageButton(
            title = stringResource(R.string.title_pref_view_and_share_log),
            text = stringResource(R.string.summary_pref_view_and_share_log),
            icon = Icons.Outlined.FindInPage,
            onClick = onViewLogClick,
        )

        OptionPageButton(
            title = stringResource(R.string.title_pref_share_logcat),
            text = stringResource(R.string.summary_pref_share_logcat),
            icon = Icons.Outlined.Android,
            onClick = onShareLogcatClick,
        )

        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun KeyEventActionMethodRow(
    modifier: Modifier = Modifier,
    isExpertModeSelected: Boolean,
    onSelected: (isExpertModeSelected: Boolean) -> Unit,
) {
    Column(modifier) {
        val buttonStates = listOf(
            false to stringResource(R.string.fix_key_event_action_input_method_title),
            true to stringResource(R.string.expert_mode_app_bar_title),
        )

        Text(
            text = stringResource(R.string.title_pref_key_event_actions_use_system_bridge),
            style = MaterialTheme.typography.bodyLarge,
        )

        Text(
            text = stringResource(R.string.summary_pref_key_event_actions_use_system_bridge),
            style = MaterialTheme.typography.bodyMedium,
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            for ((isExpertMode, text) in buttonStates) {
                RadioButtonText(
                    text = text,
                    isSelected = isExpertMode == isExpertModeSelected,
                    onSelected = { onSelected(isExpertMode) },
                )
            }
        }
    }
}

@Preview(heightDp = 1500)
@Composable
private fun Preview() {
    KeyMapperTheme {
        SettingsScreen(modifier = Modifier.fillMaxSize(), onBackClick = {}) {
            Content(
                state = MainSettingsState(),
            )
        }
    }
}
