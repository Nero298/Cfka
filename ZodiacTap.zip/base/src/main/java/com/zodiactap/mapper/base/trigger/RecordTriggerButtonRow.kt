package com.zodiactap.mapper.base.trigger

import android.content.res.Configuration
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.OfflineBolt
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zodiactap.mapper.base.R
import com.zodiactap.mapper.base.compose.KeyMapperTheme
import com.zodiactap.mapper.base.compose.LocalCustomColorsPalette

@Composable
fun RecordTriggerButtonRow(
    modifier: Modifier = Modifier,
    onRecordTriggerClick: () -> Unit = {},
    recordTriggerState: RecordTriggerState,
    expertModeRecordSwitchState: ExpertModeRecordSwitchState,
    onExpertModeSwitchChange: (Boolean) -> Unit = {},
    onAdvancedTriggersClick: () -> Unit = {},
) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (expertModeRecordSwitchState.isVisible) {
                ExpertModeSwitch(
                    state = expertModeRecordSwitchState,
                    onCheckedChange = onExpertModeSwitchChange,
                )

                Spacer(modifier = Modifier.width(8.dp))
            }

            RecordTriggerButton(
                modifier = Modifier.weight(1f),
                recordTriggerState,
                isExpertModeRecordingEnabled = expertModeRecordSwitchState.isChecked,
                onClick = onRecordTriggerClick,
            )

            Spacer(modifier = Modifier.width(8.dp))

            AdvancedTriggersButton(onClick = onAdvancedTriggersClick)
        }
    }
}

@Composable
private fun ExpertModeSwitch(
    modifier: Modifier = Modifier,
    state: ExpertModeRecordSwitchState,
    onCheckedChange: (Boolean) -> Unit,
) {
    Switch(
        modifier = modifier,
        checked = state.isChecked,
        enabled = state.isEnabled,
//        colors = SwitchDefaults.colors(
//            checkedTrackColor = MaterialTheme.colorScheme.surface,
//            checkedThumbColor = LocalCustomColorsPalette.current.greenContainer,
//            checkedIconColor = LocalCustomColorsPalette.current.onGreenContainer,
//            checkedBorderColor = LocalCustomColorsPalette.current.green,
//        ),
        onCheckedChange = onCheckedChange,
        thumbContent = {
            Icon(
                modifier = Modifier.padding(2.dp),
                imageVector = Icons.Outlined.OfflineBolt,
                contentDescription = null,
            )
        },
    )
}

@Composable
fun RecordTriggerButton(
    modifier: Modifier,
    state: RecordTriggerState,
    isExpertModeRecordingEnabled: Boolean,
    onClick: () -> Unit,
) {
    val colors = ButtonDefaults.filledTonalButtonColors().copy(
        containerColor = LocalCustomColorsPalette.current.red,
        contentColor = LocalCustomColorsPalette.current.onRed,
    )

    val text: String = when (state) {
        is RecordTriggerState.CountingDown ->
            stringResource(R.string.button_recording_trigger_countdown, state.timeLeft)

        else -> if (isExpertModeRecordingEnabled) {
            stringResource(R.string.button_record_trigger_expert_mode)
        } else {
            stringResource(R.string.button_record_trigger)
        }
    }

    // Create pulsing animation for the recording dot
    val infiniteTransition = rememberInfiniteTransition(label = "recording_dot_pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "recording_dot_alpha",
    )

    FilledTonalButton(
        modifier = modifier,
        onClick = onClick,
        colors = colors,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // White recording dot
            if (state is RecordTriggerState.CountingDown) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .alpha(alpha)
                        .background(
                            color = Color.White,
                            shape = CircleShape,
                        ),
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            BasicText(
                text = text,
                maxLines = 1,
                autoSize = TextAutoSize.StepBased(
                    minFontSize = 5.sp,
                    maxFontSize = MaterialTheme.typography.labelLarge.fontSize,
                ),
                style = MaterialTheme.typography.labelLarge,
                color = { colors.contentColor },
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun AdvancedTriggersButton(modifier: Modifier = Modifier, onClick: () -> Unit) {
    IconButton(
        modifier = modifier,
        onClick = onClick,
        colors = IconButtonDefaults.iconButtonColors(
            containerColor = LocalCustomColorsPalette.current.amber,
            contentColor = LocalCustomColorsPalette.current.onAmber,
        ),
    ) {
        Icon(Icons.Outlined.ShoppingCart, contentDescription = null)
    }
}

@Preview(widthDp = 400)
@Composable
private fun PreviewCountingDown() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.CountingDown(3),
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = true,
                    isChecked = true,
                    isEnabled = true,
                ),
            )
        }
    }
}

@Preview(widthDp = 400)
@Composable
private fun PreviewStopped() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.Idle,
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = true,
                    isChecked = false,
                    isEnabled = true,
                ),
            )
        }
    }
}

@Preview(widthDp = 400, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun PreviewStoppedDark() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.Idle,
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = true,
                    isChecked = true,
                    isEnabled = true,
                ),
            )
        }
    }
}

@Preview(widthDp = 300)
@Composable
private fun PreviewStoppedCompact() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.Idle,
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = true,
                    isChecked = false,
                    isEnabled = true,
                ),
            )
        }
    }
}

@Preview(widthDp = 400)
@Composable
private fun PreviewExpertModeSwitchHidden() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.Idle,
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = false,
                    isChecked = false,
                    isEnabled = true,
                ),
            )
        }
    }
}

@Preview(widthDp = 400)
@Composable
private fun PreviewExpertModeSwitchDisabled() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.Idle,
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = true,
                    isChecked = true,
                    isEnabled = false,
                ),
            )
        }
    }
}

@Preview(widthDp = 400)
@Composable
private fun PreviewCompleted() {
    KeyMapperTheme {
        Surface {
            RecordTriggerButtonRow(
                modifier = Modifier.fillMaxWidth(),
                recordTriggerState = RecordTriggerState.Completed(emptyList()),
                expertModeRecordSwitchState = ExpertModeRecordSwitchState(
                    isVisible = true,
                    isChecked = false,
                    isEnabled = true,
                ),
            )
        }
    }
}
