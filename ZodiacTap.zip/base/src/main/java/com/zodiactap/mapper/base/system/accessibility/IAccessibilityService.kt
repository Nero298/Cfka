package com.zodiactap.mapper.base.system.accessibility

import android.os.Build
import androidx.annotation.RequiresApi
import com.zodiactap.mapper.base.actions.talkback.TalkBackGestureType
import com.zodiactap.mapper.base.system.inputmethod.SwitchImeInterface
import com.zodiactap.mapper.common.utils.InputEventAction
import com.zodiactap.mapper.common.utils.KMResult
import com.zodiactap.mapper.common.utils.PinchScreenType
import kotlinx.coroutines.flow.Flow

interface IAccessibilityService : SwitchImeInterface {
    fun doGlobalAction(action: Int): KMResult<*>

    fun tapScreen(x: Int, y: Int, inputEventAction: InputEventAction): KMResult<*>

    fun swipeScreen(
        xStart: Int,
        yStart: Int,
        xEnd: Int,
        yEnd: Int,
        fingerCount: Int,
        duration: Int,
        inputEventAction: InputEventAction,
    ): KMResult<*>

    fun pinchScreen(
        x: Int,
        y: Int,
        distance: Int,
        pinchType: PinchScreenType,
        fingerCount: Int,
        duration: Int,
        inputEventAction: InputEventAction,
    ): KMResult<*>

    val isFingerprintGestureDetectionAvailable: Boolean

    var serviceFlags: Int?
    var serviceFeedbackType: Int?
    var serviceEventTypes: Int?
    var notificationTimeout: Long?

    fun performActionOnNode(
        findNode: (node: AccessibilityNodeModel) -> Boolean,
        performAction: (node: AccessibilityNodeModel) -> AccessibilityNodeAction?,
    ): KMResult<*>

    val rootNode: AccessibilityNodeModel?
    val activeWindowPackage: Flow<String?>
    val activeWindowPackageNames: List<String>

    fun hideKeyboard()
    fun showKeyboard()

    /**
     * Whether the keyboard is force hidden by the accessibility service SoftKeyboardController
     */
    val isKeyboardHidden: Flow<Boolean>

    /**
     * Whether the input method is visible on the screen.
     */
    val isInputMethodVisible: Flow<Boolean>

    /**
     * Whether the notification shade (notification panel / status bar) is expanded.
     * Detection is best-effort; accuracy may vary across OEMs and Android versions.
     */
    val isNotificationShadeExpanded: Flow<Boolean>

    fun findFocussedNode(focus: Int): AccessibilityNodeModel?

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun injectText(text: String)

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun performImeAction()

    fun performTalkBackGesture(gesture: TalkBackGestureType): KMResult<*>
}
