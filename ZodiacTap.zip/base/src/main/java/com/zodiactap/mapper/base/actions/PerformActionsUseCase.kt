package com.zodiactap.mapper.base.actions

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityNodeInfo
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import com.zodiactap.mapper.base.R
import com.zodiactap.mapper.base.actions.sound.SoundsManager
import com.zodiactap.mapper.base.input.InjectKeyEventModel
import com.zodiactap.mapper.base.input.InputEventHub
import com.zodiactap.mapper.base.system.accessibility.AccessibilityNodeAction
import com.zodiactap.mapper.base.system.accessibility.AccessibilityNodeModel
import com.zodiactap.mapper.base.system.accessibility.IAccessibilityService
import com.zodiactap.mapper.base.system.inputmethod.ImeInputEventInjector
import com.zodiactap.mapper.base.system.inputmethod.SwitchImeInterface
import com.zodiactap.mapper.base.system.navigation.OpenMenuHelper
import com.zodiactap.mapper.base.system.notifications.NotificationController
import com.zodiactap.mapper.base.utils.getFullMessage
import com.zodiactap.mapper.base.utils.ui.ResourceProvider
import com.zodiactap.mapper.common.utils.InputEventAction
import com.zodiactap.mapper.common.utils.KMError
import com.zodiactap.mapper.common.utils.KMError.SdkVersionTooLow
import com.zodiactap.mapper.common.utils.KMResult
import com.zodiactap.mapper.common.utils.Orientation
import com.zodiactap.mapper.common.utils.Success
import com.zodiactap.mapper.common.utils.firstBlocking
import com.zodiactap.mapper.common.utils.getWordBoundaries
import com.zodiactap.mapper.common.utils.onFailure
import com.zodiactap.mapper.common.utils.onSuccess
import com.zodiactap.mapper.common.utils.otherwise
import com.zodiactap.mapper.common.utils.success
import com.zodiactap.mapper.common.utils.then
import com.zodiactap.mapper.data.Keys
import com.zodiactap.mapper.data.PreferenceDefaults
import com.zodiactap.mapper.data.repositories.PreferenceRepository
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionManager
import com.zodiactap.mapper.sysbridge.manager.isConnected
import com.zodiactap.mapper.system.airplanemode.AirplaneModeAdapter
import com.zodiactap.mapper.system.apps.AppShortcutAdapter
import com.zodiactap.mapper.system.apps.PackageManagerAdapter
import com.zodiactap.mapper.system.bluetooth.BluetoothAdapter
import com.zodiactap.mapper.system.camera.CameraAdapter
import com.zodiactap.mapper.system.devices.DevicesAdapter
import com.zodiactap.mapper.system.display.DisplayAdapter
import com.zodiactap.mapper.system.files.FileAdapter
import com.zodiactap.mapper.system.files.FileUtils
import com.zodiactap.mapper.system.inputevents.Scancode
import com.zodiactap.mapper.system.inputmethod.InputMethodAdapter
import com.zodiactap.mapper.system.intents.IntentAdapter
import com.zodiactap.mapper.system.intents.IntentTarget
import com.zodiactap.mapper.system.lock.LockScreenAdapter
import com.zodiactap.mapper.system.media.MediaAdapter
import com.zodiactap.mapper.system.network.NetworkAdapter
import com.zodiactap.mapper.system.nfc.NfcAdapter
import com.zodiactap.mapper.system.notifications.NotificationAdapter
import com.zodiactap.mapper.system.notifications.NotificationModel
import com.zodiactap.mapper.system.notifications.NotificationReceiverAdapter
import com.zodiactap.mapper.system.notifications.NotificationServiceEvent
import com.zodiactap.mapper.system.phone.PhoneAdapter
import com.zodiactap.mapper.system.popup.ToastAdapter
import com.zodiactap.mapper.system.ringtones.RingtoneAdapter
import com.zodiactap.mapper.system.root.SuAdapter
import com.zodiactap.mapper.system.settings.SettingType
import com.zodiactap.mapper.system.settings.SettingsAdapter
import com.zodiactap.mapper.system.shell.ShellAdapter
import com.zodiactap.mapper.system.url.OpenUrlAdapter
import com.zodiactap.mapper.system.volume.RingerMode
import com.zodiactap.mapper.system.volume.VolumeAdapter
import com.zodiactap.mapper.system.volume.VolumeStream
import kotlin.math.absoluteValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber

class PerformActionsUseCaseImpl @AssistedInject constructor(
    @Assisted
    private val coroutineScope: CoroutineScope,
    @Assisted
    private val service: IAccessibilityService,
    private val inputMethodAdapter: InputMethodAdapter,
    private val switchImeInterface: SwitchImeInterface,
    private val fileAdapter: FileAdapter,
    private val suAdapter: SuAdapter,
    private val shell: ShellAdapter,
    private val intentAdapter: IntentAdapter,
    private val getActionErrorUseCase: GetActionErrorUseCase,
    private val executeShellCommandUseCase: ExecuteShellCommandUseCase,
    private val keyMapperImeMessenger: ImeInputEventInjector,
    private val packageManagerAdapter: PackageManagerAdapter,
    private val appShortcutAdapter: AppShortcutAdapter,
    private val toastAdapter: ToastAdapter,
    private val devicesAdapter: DevicesAdapter,
    private val phoneAdapter: PhoneAdapter,
    private val audioAdapter: VolumeAdapter,
    private val cameraAdapter: CameraAdapter,
    private val displayAdapter: DisplayAdapter,
    private val lockScreenAdapter: LockScreenAdapter,
    private val mediaAdapter: MediaAdapter,
    private val airplaneModeAdapter: AirplaneModeAdapter,
    private val networkAdapter: NetworkAdapter,
    private val bluetoothAdapter: BluetoothAdapter,
    private val nfcAdapter: NfcAdapter,
    private val openUrlAdapter: OpenUrlAdapter,
    private val resourceProvider: ResourceProvider,
    private val soundsManager: SoundsManager,
    private val notificationReceiverAdapter: NotificationReceiverAdapter,
    private val notificationAdapter: NotificationAdapter,
    private val ringtoneAdapter: RingtoneAdapter,
    private val settingsRepository: PreferenceRepository,
    private val inputEventHub: InputEventHub,
    private val systemBridgeConnectionManager: SystemBridgeConnectionManager,
    private val settingsAdapter: SettingsAdapter,
) : PerformActionsUseCase {

    companion object {
        private const val SETTING_NIGHT_DISPLAY_ACTIVATED = "night_display_activated"
    }

    @AssistedFactory
    interface Factory {
        fun create(
            coroutineScope: CoroutineScope,
            accessibilityService: IAccessibilityService,
        ): PerformActionsUseCaseImpl
    }

    private val openMenuHelper by lazy {
        OpenMenuHelper(
            service,
            inputEventHub,
        )
    }

    private val performKeyEventActionDelegate: PerformKeyEventActionDelegate =
        PerformKeyEventActionDelegate(
            coroutineScope,
            settingsRepository,
            inputEventHub,
            devicesAdapter,
        )

    override suspend fun perform(
        action: ActionData,
        inputEventAction: InputEventAction,
        keyMetaState: Int,
        device: PerformActionTriggerDevice,
    ) {
        /**
         * Is null if the action is being performed asynchronously
         */
        val result: KMResult<*>

        when (action) {
            is ActionData.App -> {
                result = packageManagerAdapter.openApp(action.packageName)
            }

            is ActionData.AppShortcut -> {
                result = appShortcutAdapter.launchShortcut(action.uri)
            }

            is ActionData.Intent -> {
                result = intentAdapter.send(action.target, action.uri, action.extras)
            }

            is ActionData.InputKeyEvent -> {
                result = performKeyEventActionDelegate.perform(
                    action,
                    inputEventAction,
                    keyMetaState,
                    device,
                )
            }

            is ActionData.PhoneCall -> {
                result = phoneAdapter.startCall(action.number)
            }

            is ActionData.SendSms -> {
                result = phoneAdapter.sendSms(action.number, action.message)
            }

            is ActionData.ComposeSms -> {
                result = phoneAdapter.composeSms(action.number, action.message)
            }

            is ActionData.DoNotDisturb.Enable -> {
                result = audioAdapter.enableDndMode(action.dndMode)
            }

            is ActionData.DoNotDisturb.Toggle -> {
                result = if (audioAdapter.isDndEnabled()) {
                    audioAdapter.disableDndMode()
                } else {
                    audioAdapter.enableDndMode(action.dndMode)
                }
            }

            is ActionData.Volume.SetRingerMode -> {
                result = audioAdapter.setRingerMode(action.ringerMode)
            }

            is ActionData.ControlMediaForApp.FastForward -> {
                result = mediaAdapter.fastForward(action.packageName)
            }

            is ActionData.ControlMediaForApp.NextTrack -> {
                result = mediaAdapter.nextTrack(action.packageName)
            }

            is ActionData.ControlMediaForApp.Pause -> {
                result = mediaAdapter.pause(action.packageName)
            }

            is ActionData.ControlMediaForApp.Play -> {
                result = mediaAdapter.play(action.packageName)
            }

            is ActionData.ControlMediaForApp.PlayPause -> {
                result = mediaAdapter.playPause(action.packageName)
            }

            is ActionData.ControlMediaForApp.PreviousTrack -> {
                result = mediaAdapter.previousTrack(action.packageName)
            }

            is ActionData.ControlMediaForApp.Rewind -> {
                result = mediaAdapter.rewind(action.packageName)
            }

            is ActionData.ControlMediaForApp.Stop -> {
                result = mediaAdapter.stop(action.packageName)
            }

            is ActionData.ControlMediaForApp.StepForward -> {
                result = mediaAdapter.stepForward(action.packageName)
            }

            is ActionData.ControlMediaForApp.StepBackward -> {
                result = mediaAdapter.stepBackward(action.packageName)
            }

            is ActionData.Rotation.CycleRotations -> {
                result = displayAdapter.disableAutoRotate().then {
                    val currentOrientation = displayAdapter.cachedOrientation

                    val index = action.orientations.indexOf(currentOrientation)

                    val nextOrientation = if (index == action.orientations.lastIndex) {
                        action.orientations[0]
                    } else {
                        action.orientations[index + 1]
                    }

                    displayAdapter.setOrientation(nextOrientation)
                }
            }

            is ActionData.Flashlight.Disable -> {
                result = cameraAdapter.disableFlashlight(action.lens)
            }

            is ActionData.Flashlight.Enable -> {
                result = cameraAdapter.enableFlashlight(action.lens, action.strengthPercent)
            }

            is ActionData.Flashlight.Toggle -> {
                result = cameraAdapter.toggleFlashlight(action.lens, action.strengthPercent)
            }

            is ActionData.Flashlight.ChangeStrength -> {
                result = cameraAdapter.changeFlashlightStrength(action.lens, action.percent)
            }

            is ActionData.SwitchKeyboard -> {
                switchImeInterface.switchIme(action.imeId)

                // See issue #1064. Wait for the input method to finish switching before returning.
                val chosenIme = withTimeoutOrNull(2000) {
                    inputMethodAdapter.chosenIme.filterNotNull().first { it.id == action.imeId }
                }

                if (chosenIme == null) {
                    result = KMError.SwitchImeFailed
                } else {
                    result = Success(Unit)
                }
            }

            is ActionData.Volume.Down -> {
                result = audioAdapter.lowerVolume(
                    stream = action.volumeStream,
                    showVolumeUi = action.showVolumeUi,
                )
            }

            is ActionData.Volume.Up -> {
                result = audioAdapter.raiseVolume(
                    stream = action.volumeStream,
                    showVolumeUi = action.showVolumeUi,
                )
            }

            is ActionData.Volume.Mute -> {
                result = audioAdapter.muteVolume(showVolumeUi = action.showVolumeUi)
            }

            is ActionData.Volume.ToggleMute -> {
                result = audioAdapter.toggleMuteVolume(showVolumeUi = action.showVolumeUi)
            }

            is ActionData.Volume.UnMute -> {
                result = audioAdapter.unmuteVolume(showVolumeUi = action.showVolumeUi)
            }

            is ActionData.Microphone.Mute -> {
                result = audioAdapter.muteMicrophone().onSuccess {
                    toastAdapter.show(resourceProvider.getString(R.string.toast_microphone_muted))
                }
            }

            is ActionData.Microphone.Unmute -> {
                result = audioAdapter.unmuteMicrophone().onSuccess {
                    toastAdapter.show(resourceProvider.getString(R.string.toast_microphone_unmuted))
                }
            }

            is ActionData.Microphone.Toggle -> {
                result = if (audioAdapter.isMicrophoneMuted) {
                    audioAdapter.unmuteMicrophone().onSuccess {
                        toastAdapter.show(
                            resourceProvider.getString(R.string.toast_microphone_unmuted),
                        )
                    }
                } else {
                    audioAdapter.muteMicrophone().onSuccess {
                        toastAdapter.show(
                            resourceProvider.getString(R.string.toast_microphone_muted),
                        )
                    }
                }
            }

            is ActionData.TapScreen -> {
                result = service.tapScreen(action.x, action.y, inputEventAction)
            }

            is ActionData.SwipeScreen -> {
                result = service.swipeScreen(
                    action.xStart,
                    action.yStart,
                    action.xEnd,
                    action.yEnd,
                    action.fingerCount,
                    action.duration,
                    inputEventAction,
                )
            }

            is ActionData.PinchScreen -> {
                result = service.pinchScreen(
                    action.x,
                    action.y,
                    action.distance,
                    action.pinchType,
                    action.fingerCount,
                    action.duration,
                    inputEventAction,
                )
            }

            is ActionData.Text -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    service.injectText(action.text)
                } else {
                    keyMapperImeMessenger.inputText(action.text)
                }
                result = Success(Unit)
            }

            is ActionData.Url -> {
                result = openUrlAdapter.openUrl(action.url)
            }

            is ActionData.Sound.SoundFile -> {
                ringtoneAdapter.stopPlaying()
                result = soundsManager.getSound(action.soundUid).then { file ->
                    mediaAdapter.playFile(file.uri, VolumeStream.ACCESSIBILITY)
                }
            }

            is ActionData.Sound.Ringtone -> {
                result = mediaAdapter.stopFileMedia().then {
                    ringtoneAdapter.play(action.uri)
                }
            }

            is ActionData.Wifi.Toggle -> {
                result = if (networkAdapter.isWifiEnabled()) {
                    networkAdapter.disableWifi()
                } else {
                    networkAdapter.enableWifi()
                }
            }

            is ActionData.Wifi.Enable -> {
                result = networkAdapter.enableWifi()
            }

            is ActionData.Wifi.Disable -> {
                result = networkAdapter.disableWifi()
            }

            is ActionData.Bluetooth.Toggle -> {
                result = if (bluetoothAdapter.isBluetoothEnabled.firstBlocking()) {
                    bluetoothAdapter.disable()
                } else {
                    bluetoothAdapter.enable()
                }
            }

            is ActionData.Bluetooth.Enable -> {
                result = bluetoothAdapter.enable()
            }

            is ActionData.Bluetooth.Disable -> {
                result = bluetoothAdapter.disable()
            }

            is ActionData.MobileData.Toggle -> {
                result = if (networkAdapter.isMobileDataEnabled()) {
                    networkAdapter.disableMobileData()
                } else {
                    networkAdapter.enableMobileData()
                }
            }

            is ActionData.MobileData.Enable -> {
                result = networkAdapter.enableMobileData()
            }

            is ActionData.MobileData.Disable -> {
                result = networkAdapter.disableMobileData()
            }

            is ActionData.Hotspot.Toggle -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    result = networkAdapter.isHotspotEnabled().then { isEnabled ->
                        if (isEnabled) {
                            networkAdapter.disableHotspot()
                        } else {
                            networkAdapter.enableHotspot()
                        }
                    }
                } else {
                    result = SdkVersionTooLow(minSdk = Build.VERSION_CODES.R)
                }
            }

            is ActionData.Hotspot.Enable -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    result = networkAdapter.enableHotspot()
                } else {
                    result = SdkVersionTooLow(minSdk = Build.VERSION_CODES.R)
                }
            }

            is ActionData.Hotspot.Disable -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    result = networkAdapter.disableHotspot()
                } else {
                    result = SdkVersionTooLow(minSdk = Build.VERSION_CODES.R)
                }
            }

            is ActionData.Brightness.ToggleAuto -> {
                result = if (displayAdapter.isAutoBrightnessEnabled()) {
                    displayAdapter.disableAutoBrightness()
                } else {
                    displayAdapter.enableAutoBrightness()
                }
            }

            is ActionData.Brightness.DisableAuto -> {
                result = displayAdapter.disableAutoBrightness()
            }

            is ActionData.Brightness.EnableAuto -> {
                result = displayAdapter.enableAutoBrightness()
            }

            is ActionData.Brightness.Increase -> {
                result = displayAdapter.increaseBrightness()
            }

            is ActionData.Brightness.Decrease -> {
                result = displayAdapter.decreaseBrightness()
            }

            is ActionData.Rotation.ToggleAuto -> {
                result = if (displayAdapter.isAutoRotateEnabled()) {
                    displayAdapter.disableAutoRotate()
                } else {
                    displayAdapter.enableAutoRotate()
                }
            }

            is ActionData.Rotation.EnableAuto -> {
                result = displayAdapter.enableAutoRotate()
            }

            is ActionData.Rotation.DisableAuto -> {
                result = displayAdapter.disableAutoRotate()
            }

            is ActionData.Rotation.Portrait -> {
                displayAdapter.disableAutoRotate()
                result = displayAdapter.setOrientation(Orientation.ORIENTATION_0)
            }

            is ActionData.Rotation.Landscape -> {
                displayAdapter.disableAutoRotate()
                result = displayAdapter.setOrientation(Orientation.ORIENTATION_90)
            }

            is ActionData.Rotation.SwitchOrientation -> {
                if (displayAdapter.cachedOrientation == Orientation.ORIENTATION_180 ||
                    displayAdapter.cachedOrientation == Orientation.ORIENTATION_0
                ) {
                    result = displayAdapter.setOrientation(Orientation.ORIENTATION_90)
                } else {
                    result = displayAdapter.setOrientation(Orientation.ORIENTATION_0)
                }
            }

            is ActionData.Volume.CycleRingerMode -> {
                result = when (audioAdapter.ringerMode) {
                    RingerMode.NORMAL -> audioAdapter.setRingerMode(RingerMode.VIBRATE)
                    RingerMode.VIBRATE -> audioAdapter.setRingerMode(RingerMode.SILENT)
                    RingerMode.SILENT -> audioAdapter.setRingerMode(RingerMode.NORMAL)
                }
            }

            is ActionData.Volume.CycleVibrateRing -> {
                result = when (audioAdapter.ringerMode) {
                    RingerMode.NORMAL -> audioAdapter.setRingerMode(RingerMode.VIBRATE)
                    RingerMode.VIBRATE -> audioAdapter.setRingerMode(RingerMode.NORMAL)
                    RingerMode.SILENT -> audioAdapter.setRingerMode(RingerMode.NORMAL)
                }
            }

            is ActionData.DoNotDisturb.Disable -> {
                result = audioAdapter.disableDndMode()
            }

            is ActionData.StatusBar.ExpandNotifications -> {
                val globalAction = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS

                result = service.doGlobalAction(globalAction).otherwise {
                    getShellAdapter(useRoot = false).execute("cmd statusbar expand-notifications")
                }
            }

            is ActionData.StatusBar.ToggleNotifications -> {
                result =
                    if (service.rootNode?.packageName == "com.android.systemui") {
                        closeStatusBarShade()
                    } else {
                        val globalAction = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS

                        service.doGlobalAction(globalAction).otherwise {
                            getShellAdapter(
                                useRoot = false,
                            ).execute("cmd statusbar expand-notifications")
                        }
                    }
            }

            is ActionData.StatusBar.ExpandQuickSettings -> {
                val globalAction = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS

                result =
                    service.doGlobalAction(globalAction).otherwise {
                        getShellAdapter(useRoot = false).execute("cmd statusbar expand-settings")
                    }
            }

            is ActionData.StatusBar.ToggleQuickSettings -> {
                result =
                    if (service.rootNode?.packageName == "com.android.systemui") {
                        closeStatusBarShade()
                    } else {
                        val globalAction = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS

                        service.doGlobalAction(globalAction).otherwise {
                            getShellAdapter(
                                useRoot = false,
                            ).execute("cmd statusbar expand-settings")
                        }
                    }
            }

            is ActionData.StatusBar.Collapse -> {
                result = closeStatusBarShade()
            }

            is ActionData.ControlMedia.Pause -> {
                result = mediaAdapter.pause()
            }

            is ActionData.ControlMedia.Play -> {
                result = mediaAdapter.play()
            }

            is ActionData.ControlMedia.PlayPause -> {
                result = mediaAdapter.playPause()
            }

            is ActionData.ControlMedia.NextTrack -> {
                result = mediaAdapter.nextTrack()
            }

            is ActionData.ControlMedia.PreviousTrack -> {
                result = mediaAdapter.previousTrack()
            }

            is ActionData.ControlMedia.FastForward -> {
                result = mediaAdapter.fastForward()
            }

            is ActionData.ControlMedia.Rewind -> {
                result = mediaAdapter.rewind()
            }

            is ActionData.ControlMedia.Stop -> {
                result = mediaAdapter.stop()
            }

            is ActionData.ControlMedia.StepForward -> {
                result = mediaAdapter.stepForward()
            }

            is ActionData.ControlMedia.StepBackward -> {
                result = mediaAdapter.stepBackward()
            }

            is ActionData.GoBack -> {
                result =
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            }

            is ActionData.GoHome -> {
                result =
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            }

            is ActionData.OpenRecents -> {
                result =
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            }

            is ActionData.ToggleSplitScreen -> {
                result =
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            }

            is ActionData.GoLastApp -> {
                service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                delay(100)
                result =
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            }

            is ActionData.OpenMenu -> {
                result = openMenuHelper.openMenu()
            }

            is ActionData.Nfc.Enable -> {
                result = nfcAdapter.enable()
            }

            is ActionData.Nfc.Disable -> {
                result = nfcAdapter.disable()
            }

            is ActionData.Nfc.Toggle -> {
                result = if (nfcAdapter.isEnabled()) {
                    nfcAdapter.disable()
                } else {
                    nfcAdapter.enable()
                }
            }

            is ActionData.MoveCursor -> {
                result = service.performActionOnNode({ it.isFocused }) {
                    val actionType = when (action.direction) {
                        ActionData.MoveCursor.Direction.START ->
                            AccessibilityNodeInfo.ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY

                        ActionData.MoveCursor.Direction.END ->
                            AccessibilityNodeInfo.ACTION_NEXT_AT_MOVEMENT_GRANULARITY
                    }

                    val granularity = when (action.moveType) {
                        ActionData.MoveCursor.Type.CHAR ->
                            AccessibilityNodeInfo.MOVEMENT_GRANULARITY_CHARACTER

                        ActionData.MoveCursor.Type.WORD ->
                            AccessibilityNodeInfo.MOVEMENT_GRANULARITY_WORD

                        ActionData.MoveCursor.Type.LINE ->
                            AccessibilityNodeInfo.MOVEMENT_GRANULARITY_LINE

                        ActionData.MoveCursor.Type.PARAGRAPH ->
                            AccessibilityNodeInfo.MOVEMENT_GRANULARITY_PARAGRAPH

                        ActionData.MoveCursor.Type.PAGE ->
                            AccessibilityNodeInfo.MOVEMENT_GRANULARITY_PAGE
                    }

                    AccessibilityNodeAction(
                        actionType,
                        mapOf(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT to
                                granularity,
                            AccessibilityNodeInfo.ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN to false,
                        ),
                    )
                }
            }

            is ActionData.ToggleKeyboard -> {
                val isHidden = service.isKeyboardHidden.firstBlocking()
                if (isHidden) {
                    service.showKeyboard()
                } else {
                    service.hideKeyboard()
                }

                result = Success(Unit)
            }

            is ActionData.ShowKeyboard -> {
                service.showKeyboard()
                result = Success(Unit)
            }

            is ActionData.HideKeyboard -> {
                service.hideKeyboard()
                result = Success(Unit)
            }

            is ActionData.ShowKeyboardPicker -> {
                result = inputMethodAdapter.showImePicker(fromForeground = false)
            }

            is ActionData.PerformImeAction -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    service.performImeAction()
                    result = Success(Unit)
                } else {
                    result = SdkVersionTooLow(minSdk = Build.VERSION_CODES.TIRAMISU)
                }
            }

            is ActionData.CutText -> {
                result = service.performActionOnNode({ it.isFocused }) {
                    AccessibilityNodeAction(AccessibilityNodeInfo.ACTION_CUT)
                }
            }

            is ActionData.CopyText -> {
                result = service.performActionOnNode({ it.isFocused }) {
                    AccessibilityNodeAction(AccessibilityNodeInfo.ACTION_COPY)
                }
            }

            is ActionData.PasteText -> {
                result = service.performActionOnNode({ it.isFocused }) {
                    AccessibilityNodeAction(AccessibilityNodeInfo.ACTION_PASTE)
                }
            }

            is ActionData.SelectWordAtCursor -> {
                result = service.performActionOnNode({ it.isFocused }) { node ->
                    // it is at the cursor position if they both return the same value
                    if (node.textSelectionStart == node.textSelectionEnd) {
                        val cursorPosition = node.textSelectionStart

                        val wordBoundary =
                            node.text.toString().getWordBoundaries(cursorPosition)
                                ?: return@performActionOnNode null

                        val extras = mapOf(
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT to
                                wordBoundary.first,

                            // The index of the cursor is the index of the last char in the word + 1
                            AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT to
                                wordBoundary.second + 1,
                        )

                        AccessibilityNodeAction(
                            AccessibilityNodeInfo.ACTION_SET_SELECTION,
                            extras,
                        )
                    } else {
                        null
                    }
                }
            }

            is ActionData.SelectAllText -> {
                result = service.performActionOnNode({ it.isFocused }) { node ->
                    val text = node.text?.toString().orEmpty()
                    if (text.isEmpty()) return@performActionOnNode null

                    val extras = mapOf(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT to 0,
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT to text.length,
                    )

                    AccessibilityNodeAction(
                        AccessibilityNodeInfo.ACTION_SET_SELECTION,
                        extras,
                    )
                }
            }

            is ActionData.AirplaneMode.Toggle -> {
                result = if (airplaneModeAdapter.isEnabled()) {
                    airplaneModeAdapter.disable()
                } else {
                    airplaneModeAdapter.enable()
                }
            }

            is ActionData.AirplaneMode.Enable -> {
                result = airplaneModeAdapter.enable()
            }

            is ActionData.AirplaneMode.Disable -> {
                result = airplaneModeAdapter.disable()
            }

            is ActionData.Screenshot -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                    val picturesFolder = fileAdapter.getPicturesFolder()
                    val screenshotsFolder = "$picturesFolder/Screenshots"
                    val fileDate = FileUtils.createFileDate()

                    result =
                        getShellAdapter(
                            useRoot = true,
                        ).execute(
                            "mkdir -p $screenshotsFolder; screencap -p $screenshotsFolder/Screenshot_$fileDate.png",
                        )
                            .onSuccess {
                                // Wait 3 seconds so the message isn't shown in the screenshot.
                                delay(3000)

                                toastAdapter.show(
                                    resourceProvider.getString(
                                        R.string.toast_screenshot_taken,
                                    ),
                                )
                            }
                } else {
                    result =
                        service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                }
            }

            is ActionData.VoiceAssistant -> {
                result = packageManagerAdapter.launchVoiceAssistant()
            }

            is ActionData.DeviceAssistant -> {
                result = packageManagerAdapter.launchDeviceAssistant()
            }

            is ActionData.OpenCamera -> {
                result = packageManagerAdapter.launchCameraApp()
            }

            is ActionData.LockDevice -> {
                result = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                    getShellAdapter(
                        useRoot = true,
                    ).execute("input keyevent ${KeyEvent.KEYCODE_POWER}")
                } else {
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                }
            }

            is ActionData.ScreenOnOff -> {
                if (systemBridgeConnectionManager.isConnected()) {
                    val model = InjectKeyEventModel(
                        keyCode = KeyEvent.KEYCODE_POWER,
                        action = KeyEvent.ACTION_DOWN,
                        metaState = 0,
                        deviceId = -1,
                        scanCode = Scancode.KEY_POWER,
                        source = InputDevice.SOURCE_UNKNOWN,
                    )
                    result = inputEventHub.injectKeyEvent(model, useSystemBridgeIfAvailable = true)
                        .then {
                            inputEventHub.injectKeyEvent(
                                model.copy(action = KeyEvent.ACTION_UP),
                                useSystemBridgeIfAvailable = true,
                            )
                        }
                } else {
                    result =
                        getShellAdapter(
                            useRoot = true,
                        ).execute("input keyevent ${KeyEvent.KEYCODE_POWER}")
                }
            }

            is ActionData.SecureLock -> {
                result = lockScreenAdapter.secureLockDevice()
            }

            is ActionData.ConsumeKeyEvent -> {
                result = Success(Unit)
            }

            is ActionData.OpenSettings -> {
                result = packageManagerAdapter.launchSettingsApp()
            }

            is ActionData.ShowPowerMenu -> {
                result =
                    service.doGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            }

            is ActionData.Volume.ShowDialog -> {
                result = audioAdapter.showVolumeUi()
            }

            ActionData.DismissAllNotifications -> {
                result =
                    notificationReceiverAdapter.send(
                        NotificationServiceEvent.DismissAllNotifications,
                    )
            }

            ActionData.DismissLastNotification -> {
                result =
                    notificationReceiverAdapter.send(
                        NotificationServiceEvent.DismissLastNotification,
                    )
            }

            is ActionData.CreateNotification -> {
                // Use the hashcode of the action instance as the unique notification ID
                val notificationId = action.hashCode().absoluteValue

                val notification = NotificationModel(
                    id = notificationId,
                    channel = NotificationController.CHANNEL_CUSTOM_NOTIFICATIONS,
                    title = action.title,
                    text = action.text,
                    icon = R.drawable.ic_notification_play,
                    showOnLockscreen = false,
                    onGoing = false,
                    autoCancel = true,
                    timeout = action.timeoutMs,
                    bigTextStyle = true,
                )

                notificationAdapter.showNotification(notification)
                result = success()
            }

            is ActionData.Toast -> {
                toastAdapter.show(
                    message = action.message,
                    isLong = action.duration == ActionData.Toast.Duration.LONG,
                )
                result = success()
            }

            ActionData.AnswerCall -> {
                phoneAdapter.answerCall()
                result = success()
            }

            ActionData.EndCall -> {
                phoneAdapter.endCall()
                result = success()
            }

            ActionData.DeviceControls -> {
                @Suppress("ktlint:standard:max-line-length")
                result = intentAdapter.send(
                    IntentTarget.ACTIVITY,
                    uri = "#Intent;action=android.intent.action.MAIN;package=com.android.systemui;component=com.android.systemui/.controls.ui.ControlsActivity;end",
                    extras = emptyList(),
                )
            }

            is ActionData.HttpRequest -> {
                result = networkAdapter.sendHttpRequest(
                    method = action.method,
                    url = action.url,
                    body = action.body,
                    authorizationHeader = action.authorizationHeader,
                )
            }

            is ActionData.ShellCommand -> {
                result = executeShellCommandUseCase.execute(
                    command = action.command,
                    executionMode = action.executionMode,
                    timeoutMillis = action.timeoutMillis.toLong(),
                )
            }

            is ActionData.InteractUiElement -> {
                if (service.activeWindowPackage.first() != action.packageName) {
                    result = KMError.UiElementNotFound
                } else {
                    result = service.performActionOnNode(
                        findNode = { node ->
                            matchAccessibilityNode(node, action)
                        },
                        performAction = {
                            AccessibilityNodeAction(
                                action = action.nodeAction.accessibilityActionId,
                            )
                        },
                    ).otherwise { KMError.UiElementNotFound }
                }
            }

            ActionData.ForceStopApp -> {
                val packageName = service.activeWindowPackageNames
                    .firstOrNull {
                        !it.contains("com.zodiactap.mapper") &&
                            it != "com.android.systemui"
                    }

                if (packageName == null) {
                    result = KMError.Exception(Exception("No foreground app found to kill"))
                } else {
                    result = systemBridgeConnectionManager.run { systemBridge ->
                        systemBridge.forceStopPackage(packageName)
                    }
                }
            }

            ActionData.ClearRecentApp -> {
                val packageName = service.activeWindowPackageNames
                    .firstOrNull { it != "com.android.systemui" }

                if (packageName == null) {
                    result =
                        KMError.Exception(
                            Exception("No foreground app found to clear from recents"),
                        )
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    result = systemBridgeConnectionManager.run { systemBridge ->
                        systemBridge.removeTasks(packageName)
                    }
                } else {
                    result = SdkVersionTooLow(minSdk = Build.VERSION_CODES.Q)
                }
            }

            is ActionData.ModifySetting -> {
                result = settingsAdapter.setValue(
                    action.settingType,
                    action.settingKey,
                    action.value,
                )
            }

            is ActionData.NightShift.Enable -> {
                result = settingsAdapter.setValue(
                    SettingType.SECURE,
                    SETTING_NIGHT_DISPLAY_ACTIVATED,
                    "1",
                )
            }

            is ActionData.NightShift.Disable -> {
                result = settingsAdapter.setValue(
                    SettingType.SECURE,
                    SETTING_NIGHT_DISPLAY_ACTIVATED,
                    "0",
                )
            }

            is ActionData.NightShift.Toggle -> {
                val currentValue = settingsAdapter.getValue(
                    SettingType.SECURE,
                    SETTING_NIGHT_DISPLAY_ACTIVATED,
                )
                val newValue = if (currentValue == "1") "0" else "1"
                result = settingsAdapter.setValue(
                    SettingType.SECURE,
                    SETTING_NIGHT_DISPLAY_ACTIVATED,
                    newValue,
                )
            }

            is ActionData.TalkBackGesture -> {
                result = service.performTalkBackGesture(action.gesture)
            }
        }

        when (result) {
            is Success -> Timber.d(
                "Performed action $action, input event type: $inputEventAction, key meta state: $keyMetaState",
            )

            is KMError -> Timber.d(
                "Failed to perform action $action, reason: ${
                    result.getFullMessage(
                        resourceProvider,
                    )
                }, action: $action, input event type: $inputEventAction, key meta state: $keyMetaState",
            )
        }

        result.showErrorMessageOnFail()
    }

    override fun getErrorSnapshot(): ActionErrorSnapshot {
        return getActionErrorUseCase.actionErrorSnapshot.firstBlocking()
    }

    override val defaultRepeatDelay: Flow<Long> =
        settingsRepository.get(Keys.defaultRepeatDelay)
            .map { it ?: PreferenceDefaults.REPEAT_DELAY }
            .map { it.toLong() }

    override val defaultRepeatRate: Flow<Long> =
        settingsRepository.get(Keys.defaultRepeatRate)
            .map { it ?: PreferenceDefaults.REPEAT_RATE }
            .map { it.toLong() }

    override val defaultHoldDownDuration: Flow<Long> =
        settingsRepository.get(Keys.defaultHoldDownDuration)
            .map { it ?: PreferenceDefaults.HOLD_DOWN_DURATION }
            .map { it.toLong() }

    private fun closeStatusBarShade(): KMResult<*> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return service
                .doGlobalAction(AccessibilityService.GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            return runBlocking {
                getShellAdapter(useRoot = false).execute("cmd statusbar collapse")
            }
        }
    }

    private fun getShellAdapter(useRoot: Boolean): ShellAdapter {
        return if (useRoot) {
            suAdapter
        } else {
            shell
        }
    }

    private fun KMResult<*>.showErrorMessageOnFail() {
        onFailure {
            toastAdapter.show(it.getFullMessage(resourceProvider))
        }
    }

    private fun matchAccessibilityNode(
        node: AccessibilityNodeModel,
        action: ActionData.InteractUiElement,
    ): Boolean {
        if (!node.actions.contains(action.nodeAction.accessibilityActionId)) {
            return false
        }

        if (compareIfNonNull(node.uniqueId, action.uniqueId)) {
            return true
        }

        if (action.contentDescription == null && action.text == null) {
            if (compareIfNonNull(node.viewResourceId, action.viewResourceId)) {
                return true
            }

            if (compareIfNonNull(node.className, action.className)) {
                return true
            }
        } else {
            if (compareIfNonNull(node.contentDescription, action.contentDescription) ||
                compareIfNonNull(node.text, action.text)
            ) {
                if (action.viewResourceId != null) {
                    return node.viewResourceId == action.viewResourceId
                }

                if (action.className != null) {
                    return node.className == action.className
                }

                return true
            }
        }

        return false
    }

    private fun <T> compareIfNonNull(a: T?, b: T?): Boolean {
        return a != null && b != null && a == b
    }
}

interface PerformActionsUseCase {
    val defaultHoldDownDuration: Flow<Long>
    val defaultRepeatDelay: Flow<Long>
    val defaultRepeatRate: Flow<Long>

    suspend fun perform(
        action: ActionData,
        inputEventAction: InputEventAction = InputEventAction.DOWN_UP,
        keyMetaState: Int = 0,
        device: PerformActionTriggerDevice = PerformActionTriggerDevice.Default,
    )

    fun getErrorSnapshot(): ActionErrorSnapshot
}
