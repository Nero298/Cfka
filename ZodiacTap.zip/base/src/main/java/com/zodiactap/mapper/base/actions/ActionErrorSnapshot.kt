package com.zodiactap.mapper.base.actions

import android.annotation.SuppressLint
import android.os.Build
import com.zodiactap.mapper.base.actions.sound.SoundsManager
import com.zodiactap.mapper.base.system.inputmethod.KeyMapperImeHelper
import com.zodiactap.mapper.base.system.inputmethod.SwitchImeInterface
import com.zodiactap.mapper.common.BuildConfigProvider
import com.zodiactap.mapper.common.models.ShellExecutionMode
import com.zodiactap.mapper.common.utils.KMError
import com.zodiactap.mapper.common.utils.firstBlocking
import com.zodiactap.mapper.common.utils.isSuccess
import com.zodiactap.mapper.common.utils.onFailure
import com.zodiactap.mapper.common.utils.onSuccess
import com.zodiactap.mapper.common.utils.valueOrNull
import com.zodiactap.mapper.data.Keys
import com.zodiactap.mapper.data.repositories.PreferenceRepository
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionManager
import com.zodiactap.mapper.sysbridge.manager.isConnected
import com.zodiactap.mapper.sysbridge.utils.SystemBridgeError
import com.zodiactap.mapper.system.SystemError
import com.zodiactap.mapper.system.apps.PackageManagerAdapter
import com.zodiactap.mapper.system.camera.CameraAdapter
import com.zodiactap.mapper.system.camera.CameraLens
import com.zodiactap.mapper.system.inputmethod.ImeInfo
import com.zodiactap.mapper.system.inputmethod.InputMethodAdapter
import com.zodiactap.mapper.system.permissions.Permission
import com.zodiactap.mapper.system.permissions.PermissionAdapter
import com.zodiactap.mapper.system.permissions.SystemFeatureAdapter
import com.zodiactap.mapper.system.ringtones.RingtoneAdapter
import com.zodiactap.mapper.system.settings.SettingType
import java.util.concurrent.ConcurrentHashMap

class LazyActionErrorSnapshot(
    private val packageManager: PackageManagerAdapter,
    private val inputMethodAdapter: InputMethodAdapter,
    private val switchImeInterface: SwitchImeInterface,
    private val permissionAdapter: PermissionAdapter,
    systemFeatureAdapter: SystemFeatureAdapter,
    cameraAdapter: CameraAdapter,
    private val soundsManager: SoundsManager,
    private val ringtoneAdapter: RingtoneAdapter,
    private val buildConfigProvider: BuildConfigProvider,
    private val systemBridgeConnectionManager: SystemBridgeConnectionManager,
    private val preferenceRepository: PreferenceRepository,
) : ActionErrorSnapshot,
    IsActionSupportedUseCase by IsActionSupportedUseCaseImpl(
        systemFeatureAdapter,
        cameraAdapter,
        permissionAdapter,
    ) {

    private val keyMapperImeHelper =
        KeyMapperImeHelper(switchImeInterface, inputMethodAdapter, buildConfigProvider.packageName)

    private val isCompatibleImeEnabled by lazy { keyMapperImeHelper.isCompatibleImeEnabled() }
    private val isCompatibleImeChosen by lazy { keyMapperImeHelper.isCompatibleImeChosen() }
    private val isVoiceAssistantInstalled by lazy { packageManager.isVoiceAssistantInstalled() }
    private val isDeviceAssistantInstalled by lazy {
        packageManager.getDeviceAssistantPackage().isSuccess
    }
    private val grantedPermissions: MutableMap<Permission, Boolean> = mutableMapOf()
    private val flashLenses by lazy {
        buildSet {
            if (cameraAdapter.getFlashInfo(CameraLens.FRONT) != null) {
                add(CameraLens.FRONT)
            }

            if (cameraAdapter.getFlashInfo(CameraLens.BACK) != null) {
                add(CameraLens.BACK)
            }
        }
    }

    private val isAppEnabledCache = ConcurrentHashMap<String, Boolean>()
    private val isAppInstalledCache = ConcurrentHashMap<String, Boolean>()

    private val isSystemBridgeConnected: Boolean by lazy {
        systemBridgeConnectionManager.isConnected()
    }

    private val keyEventActionsUseSystemBridge: Boolean by lazy {
        preferenceRepository.get(Keys.keyEventActionsUseSystemBridge).firstBlocking() ?: false
    }

    override fun getErrors(actions: List<ActionData>): Map<ActionData, KMError?> {
        // Fixes #797 and #1719
        // Store which input method would be selected if the actions run successfully.
        // Errors should not be thrown for actions that will be fixed by previous ones.
        var currentImeFromActions: ImeInfo? = null

        val errorMap = mutableMapOf<ActionData, KMError?>()

        for (action in actions) {
            if (action is ActionData.SwitchKeyboard) {
                currentImeFromActions = inputMethodAdapter.getInfoById(action.imeId).valueOrNull()
            }

            var error = getError(action)

            val isImeNotChosenError =
                error == KMError.NoCompatibleImeChosen ||
                    (
                        error is KMError.KeyEventActionError &&
                            error.baseError == KMError.NoCompatibleImeChosen
                        )

            if (isImeNotChosenError && currentImeFromActions != null) {
                val isCurrentImeCompatible =
                    KeyMapperImeHelper.isKeyMapperInputMethod(
                        currentImeFromActions.packageName,
                        buildConfigProvider.packageName,
                    )

                if (isCurrentImeCompatible) {
                    error = null
                }
            }

            errorMap[action] = error
        }

        return errorMap
    }

    override fun getError(action: ActionData): KMError? {
        val isSupportedError = isSupported(action.id)

        if (isSupportedError != null) {
            return isSupportedError
        }

        if (action is ActionData.InputKeyEvent &&
            keyEventActionsUseSystemBridge
        ) {
            if (!isSystemBridgeConnected) {
                return KMError.KeyEventActionError(SystemBridgeError.Disconnected)
            }
        } else if (action.canUseImeToPerform()) {
            if (!isCompatibleImeEnabled) {
                if (action is ActionData.InputKeyEvent) {
                    return KMError.KeyEventActionError(KMError.NoCompatibleImeEnabled)
                } else {
                    return KMError.NoCompatibleImeEnabled
                }
            }

            if (!isCompatibleImeChosen) {
                if (action is ActionData.InputKeyEvent) {
                    return KMError.KeyEventActionError(KMError.NoCompatibleImeChosen)
                } else {
                    return KMError.NoCompatibleImeChosen
                }
            }
        }

        @SuppressLint("NewApi")
        if (ActionUtils.isSystemBridgeRequired(action.id) &&
            !isSystemBridgeConnected
        ) {
            return SystemBridgeError.Disconnected
        }

        for (permission in ActionUtils.getRequiredPermissions(action.id)) {
            if (!isPermissionGranted(permission)) {
                return SystemError.PermissionDenied(permission)
            }
        }

        if (action is ActionData.Toast &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !isPermissionGranted(Permission.POST_NOTIFICATIONS)
        ) {
            return SystemError.PermissionDenied(Permission.POST_NOTIFICATIONS)
        }

        when (action) {
            is ActionData.App -> {
                return getAppError(action.packageName)
            }

            is ActionData.AppShortcut -> {
                action.packageName ?: return null

                return getAppError(action.packageName)
            }

            is ActionData.Sound.SoundFile -> {
                soundsManager.getSound(action.soundUid).onFailure { error ->
                    return error
                }
            }

            is ActionData.Sound.Ringtone -> {
                if (!ringtoneAdapter.exists(action.uri)) {
                    return KMError.CantFindSoundFile
                }
            }

            is ActionData.VoiceAssistant -> {
                if (!isVoiceAssistantInstalled) {
                    return KMError.NoVoiceAssistant
                }
            }

            is ActionData.DeviceAssistant -> {
                if (!isDeviceAssistantInstalled) {
                    return KMError.NoDeviceAssistant
                }
            }

            is ActionData.Flashlight ->
                if (!flashLenses.contains(action.lens)) {
                    return when (action.lens) {
                        CameraLens.FRONT -> KMError.FrontFlashNotFound
                        CameraLens.BACK -> KMError.BackFlashNotFound
                    }
                }

            is ActionData.SwitchKeyboard ->
                inputMethodAdapter.getInfoById(action.imeId).onFailure {
                    return it
                }

            is ActionData.ShellCommand -> {
                return when (action.executionMode) {
                    ShellExecutionMode.ROOT -> {
                        if (!isPermissionGranted(Permission.ROOT)) {
                            SystemError.PermissionDenied(Permission.ROOT)
                        } else {
                            null
                        }
                    }

                    ShellExecutionMode.ADB -> {
                        if (!isSystemBridgeConnected) {
                            SystemBridgeError.Disconnected
                        } else {
                            null
                        }
                    }

                    ShellExecutionMode.STANDARD -> null
                }
            }

            is ActionData.ModifySetting -> {
                return when (action.settingType) {
                    SettingType.SYSTEM -> {
                        if (!isPermissionGranted(Permission.WRITE_SETTINGS)) {
                            SystemError.PermissionDenied(Permission.WRITE_SETTINGS)
                        } else {
                            null
                        }
                    }

                    SettingType.SECURE,
                    SettingType.GLOBAL,
                        -> {
                        if (!isPermissionGranted(Permission.WRITE_SECURE_SETTINGS)) {
                            SystemError.PermissionDenied(Permission.WRITE_SECURE_SETTINGS)
                        } else {
                            null
                        }
                    }
                }
            }

            else -> {}
        }

        return null
    }

    private fun getAppError(packageName: String): KMError? {
        if (isAppEnabledCache.contains(packageName) && isAppInstalledCache.contains(packageName)) {
            if (isAppEnabledCache[packageName] == false) {
                return KMError.AppDisabled(packageName)
            }

            if (isAppInstalledCache[packageName] == false) {
                return KMError.AppDisabled(packageName)
            }

            return null
        }

        val isAppInstalled = packageManager.isAppInstalled(packageName)
        isAppInstalledCache[packageName] = isAppInstalled

        packageManager.isAppEnabled(packageName).onSuccess { isEnabled ->
            isAppEnabledCache[packageName] = isEnabled

            if (!isEnabled) {
                return KMError.AppDisabled(packageName)
            }
        }

        if (!isAppInstalled) {
            return KMError.AppNotFound(packageName)
        }

        return null
    }

    private fun isPermissionGranted(permission: Permission): Boolean {
        if (grantedPermissions.contains(permission)) {
            return grantedPermissions[permission]!!
        } else {
            val isGranted = permissionAdapter.isGranted(permission)
            grantedPermissions[permission] = isGranted
            return isGranted
        }
    }
}

interface ActionErrorSnapshot {
    fun getError(action: ActionData): KMError?
    fun getErrors(actions: List<ActionData>): Map<ActionData, KMError?>
}
