package com.zodiactap.mapper.base.actions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import com.zodiactap.mapper.base.utils.navigation.NavigationProvider
import com.zodiactap.mapper.base.utils.ui.DialogProvider
import com.zodiactap.mapper.base.utils.ui.ResourceProvider
import com.zodiactap.mapper.common.utils.State
import com.zodiactap.mapper.common.utils.Success
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionManager
import com.zodiactap.mapper.sysbridge.manager.isConnected
import com.zodiactap.mapper.system.settings.SettingType
import com.zodiactap.mapper.system.settings.SettingsAdapter
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@HiltViewModel
class ChooseSettingViewModel @Inject constructor(
    private val settingsAdapter: SettingsAdapter,
    private val systemBridgeConnectionManager: SystemBridgeConnectionManager,
    resourceProvider: ResourceProvider,
    navigationProvider: NavigationProvider,
    dialogProvider: DialogProvider,
) : ViewModel(),
    ResourceProvider by resourceProvider,
    DialogProvider by dialogProvider,
    NavigationProvider by navigationProvider {
    val searchQuery = MutableStateFlow<String?>(null)

    val selectedSettingType = MutableStateFlow(SettingType.SYSTEM)
    val settings: StateFlow<State<List<SettingItem>>> =
        combine(selectedSettingType, searchQuery) { type, query ->
            val allSettings = getSettings(type)

            val items = allSettings
                .filter { (key, _) -> query == null || key.contains(query, ignoreCase = true) }
                .map { (key, value) -> SettingItem(key, value) }

            State.Data(items)
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, State.Loading)

    private suspend fun getSettings(type: SettingType): Map<String, String?> {
        if (systemBridgeConnectionManager.isConnected()) {
            val namespace = when (type) {
                SettingType.SYSTEM -> "system"
                SettingType.SECURE -> "secure"
                SettingType.GLOBAL -> "global"
            }
            val result = runInterruptible(Dispatchers.IO) {
                systemBridgeConnectionManager.run { bridge ->
                    bridge.getAllSettings(namespace)
                }
            }
            if (result is Success && result.value.isNotEmpty()) {
                return parseKeyValuePairs(result.value)
            }
        }
        return settingsAdapter.getAll(type)
    }

    private fun parseKeyValuePairs(pairs: Array<String>): Map<String, String?> {
        val settings = sortedMapOf<String, String?>()
        for (entry in pairs) {
            val eqIdx = entry.indexOf('=')
            if (eqIdx < 0) continue
            val key = entry.substring(0, eqIdx)
            if (key.isBlank()) continue
            val value = if (eqIdx < entry.length - 1) entry.substring(eqIdx + 1) else null
            settings[key] = value
        }
        return settings
    }

    fun onNavigateBack() {
        viewModelScope.launch {
            popBackStack()
        }
    }

    fun onSettingClick(key: String, currentValue: String?) {
        viewModelScope.launch {
            popBackStackWithResult(
                Json.encodeToString(
                    ChooseSettingResult.serializer(),
                    ChooseSettingResult(
                        settingType = selectedSettingType.value,
                        key = key,
                        currentValue = currentValue,
                    ),
                ),
            )
        }
    }
}

data class SettingItem(val key: String, val value: String?)

@Serializable
data class ChooseSettingResult(
    val settingType: SettingType,
    val key: String,
    val currentValue: String?,
)
