package com.zodiactap.mapper.base.constraints

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zodiactap.mapper.base.R
import com.zodiactap.mapper.base.compose.KeyMapperTheme
import com.zodiactap.mapper.base.utils.ui.compose.ComposeIconInfo
import com.zodiactap.mapper.base.utils.ui.compose.SearchAppBarActions
import com.zodiactap.mapper.base.utils.ui.compose.SimpleListItemFixedHeight
import com.zodiactap.mapper.base.utils.ui.compose.SimpleListItemGroup
import com.zodiactap.mapper.base.utils.ui.compose.SimpleListItemHeader
import com.zodiactap.mapper.base.utils.ui.compose.SimpleListItemModel
import com.zodiactap.mapper.common.utils.State
import kotlinx.coroutines.flow.update

@Composable
fun ChooseConstraintScreen(modifier: Modifier = Modifier, viewModel: ChooseConstraintViewModel) {
    val state by viewModel.groups.collectAsStateWithLifecycle()
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()

    TimeConstraintBottomSheet(viewModel)
    DisplayResolutionConstraintBottomSheet(viewModel)

    ChooseConstraintScreen(
        modifier = modifier,
        state = state,
        query = query,
        onQueryChange = { newQuery -> viewModel.searchQuery.update { newQuery } },
        onCloseSearch = { viewModel.searchQuery.update { null } },
        onClickConstraint = viewModel::onListItemClick,
        onNavigateBack = viewModel::onNavigateBack,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChooseConstraintScreen(
    modifier: Modifier = Modifier,
    state: State<List<SimpleListItemGroup>>,
    query: String? = null,
    onQueryChange: (String) -> Unit = {},
    onCloseSearch: () -> Unit = {},
    onClickConstraint: (String) -> Unit = {},
    onNavigateBack: () -> Unit = {},
) {
    Scaffold(
        modifier = modifier.displayCutoutPadding(),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.choose_constraint_title)) },
            )
        },
        bottomBar = {
            BottomAppBar(
                modifier = Modifier.imePadding(),
                actions = {
                    SearchAppBarActions(
                        onCloseSearch = onCloseSearch,
                        onNavigateBack = onNavigateBack,
                        onQueryChange = onQueryChange,
                        enabled = state is State.Data,
                        query = query,
                    )
                },
            )
        },
    ) { innerPadding ->
        val layoutDirection = LocalLayoutDirection.current
        val startPadding = innerPadding.calculateStartPadding(layoutDirection)
        val endPadding = innerPadding.calculateEndPadding(layoutDirection)

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = innerPadding.calculateTopPadding(),
                    bottom = innerPadding.calculateBottomPadding(),
                    start = startPadding,
                    end = endPadding,
                ),

        ) {
            when (state) {
                State.Loading -> LoadingScreen(modifier = Modifier.fillMaxSize())

                is State.Data -> {
                    if (state.data.isEmpty()) {
                        EmptyScreen(
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        ListScreen(
                            modifier = Modifier.fillMaxSize(),
                            groups = state.data,
                            onClickConstraint = onClickConstraint,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingScreen(modifier: Modifier = Modifier) {
    Box(modifier) {
        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
    }
}

@Composable
private fun EmptyScreen(modifier: Modifier = Modifier) {
    Box(modifier) {
        val shrug = stringResource(R.string.shrug)
        val text = stringResource(R.string.action_list_empty)
        Text(
            modifier = Modifier.align(Alignment.Center),
            text = buildAnnotatedString {
                withStyle(MaterialTheme.typography.headlineLarge.toSpanStyle()) {
                    append(shrug)
                }
                appendLine()
                appendLine()
                withStyle(MaterialTheme.typography.bodyLarge.toSpanStyle()) {
                    append(text)
                }
            },
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ListScreen(
    modifier: Modifier = Modifier,
    groups: List<SimpleListItemGroup>,
    onClickConstraint: (String) -> Unit,
) {
    LazyVerticalGrid(
        modifier = modifier,
        columns = GridCells.Adaptive(minSize = 200.dp),
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (group in groups) {
            stickyHeader(contentType = "header") {
                SimpleListItemHeader(modifier = Modifier.fillMaxWidth(), text = group.header)
            }

            items(
                group.items,
                contentType = { "list_item" },
            ) { model ->
                SimpleListItemFixedHeight(
                    modifier = Modifier.fillMaxWidth(),
                    model = model,
                    onClick = { onClickConstraint(model.id) },
                )
            }
        }
    }
}

@Preview
@Composable
private fun PreviewList() {
    KeyMapperTheme {
        ChooseConstraintScreen(
            query = "Search query",
            state = State.Data(
                listOf(
                    SimpleListItemGroup(
                        header = "Apps",
                        items = listOf(
                            SimpleListItemModel(
                                "app1",
                                title = "App in foreground",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Android),
                            ),
                            SimpleListItemModel(
                                "app2",
                                title = "App not in foreground",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Android),
                            ),
                        ),
                    ),
                    SimpleListItemGroup(
                        header = "Bluetooth",
                        items = listOf(
                            SimpleListItemModel(
                                "bt1",
                                title = "Bluetooth device connected",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Bluetooth),
                            ),
                        ),
                    ),
                ),
            ),
        )
    }
}

@Preview(device = Devices.TABLET)
@Composable
private fun PreviewGrid() {
    KeyMapperTheme {
        ChooseConstraintScreen(
            state = State.Data(
                listOf(
                    SimpleListItemGroup(
                        header = "Apps",
                        items = listOf(
                            SimpleListItemModel(
                                "app1",
                                title = "App in foreground",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Android),
                            ),
                            SimpleListItemModel(
                                "app2",
                                title = "App not in foreground",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Android),
                            ),
                        ),
                    ),
                    SimpleListItemGroup(
                        header = "WiFi",
                        items = listOf(
                            SimpleListItemModel(
                                "wifi1",
                                title = "WiFi is on",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Wifi),
                                subtitle = "Requires root",
                                isSubtitleError = true,
                            ),
                            SimpleListItemModel(
                                "wifi2",
                                title = "WiFi is off",
                                icon = ComposeIconInfo.Vector(Icons.Rounded.Wifi),
                                subtitle = "Requires root",
                                isSubtitleError = true,
                                isEnabled = false,
                            ),
                        ),
                    ),
                ),
            ),
        )
    }
}

@Preview
@Composable
private fun PreviewLoading() {
    KeyMapperTheme {
        ChooseConstraintScreen(
            state = State.Loading,
        )
    }
}
