package com.zodiactap.mapper.base.system.bluetooth

import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.navigation.fragment.navArgs
import com.airbnb.epoxy.EpoxyRecyclerView
import dagger.hilt.android.AndroidEntryPoint
import com.zodiactap.mapper.base.databinding.FragmentSimpleRecyclerviewBinding
import com.zodiactap.mapper.base.fixError
import com.zodiactap.mapper.base.simple
import com.zodiactap.mapper.base.utils.ui.ListItem
import com.zodiactap.mapper.base.utils.ui.RecyclerViewUtils
import com.zodiactap.mapper.base.utils.ui.SimpleListItemOld
import com.zodiactap.mapper.base.utils.ui.SimpleRecyclerViewFragment
import com.zodiactap.mapper.base.utils.ui.TextListItem
import com.zodiactap.mapper.base.utils.ui.launchRepeatOnLifecycle
import com.zodiactap.mapper.common.utils.State
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collectLatest

@AndroidEntryPoint
class ChooseBluetoothDeviceFragment : SimpleRecyclerViewFragment<ListItem>() {

    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_ADDRESS = "extra_address"
    }

    private val args: ChooseBluetoothDeviceFragmentArgs by navArgs()

    private val viewModel: ChooseBluetoothDeviceViewModel by viewModels()

    override val listItems: Flow<State<List<ListItem>>>
        get() = viewModel.listItems

    override fun subscribeUi(binding: FragmentSimpleRecyclerviewBinding) {
        super.subscribeUi(binding)

        RecyclerViewUtils.applySimpleListItemDecorations(binding.epoxyRecyclerView)

        viewLifecycleOwner.launchRepeatOnLifecycle(Lifecycle.State.RESUMED) {
            viewModel.caption.collectLatest {
                binding.caption = it
            }
        }

        viewLifecycleOwner.launchRepeatOnLifecycle(Lifecycle.State.RESUMED) {
            viewModel.returnResult.collectLatest { device ->
                returnResult(EXTRA_ADDRESS to device.address, EXTRA_NAME to device.name)
            }
        }
    }

    override fun populateList(recyclerView: EpoxyRecyclerView, listItems: List<ListItem>) {
        recyclerView.withModels {
            listItems.forEach { listItem ->
                if (listItem is SimpleListItemOld) {
                    simple {
                        id(listItem.id)
                        model(listItem)

                        onClickListener { _ ->
                            viewModel.onBluetoothDeviceListItemClick(listItem.id)
                        }
                    }
                } else if (listItem is TextListItem.Error) {
                    fixError {
                        id(listItem.id)
                        model(listItem)
                        onFixClick { _ ->
                            viewModel.onFixMissingPermissionListItemClick()
                        }
                    }
                }
            }
        }
    }

    override fun getRequestKey(): String = args.requestKey
}
