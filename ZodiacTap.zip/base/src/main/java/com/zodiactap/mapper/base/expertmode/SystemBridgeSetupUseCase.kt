package com.zodiactap.mapper.base.expertmode

import android.os.Build
import android.os.Process
import androidx.annotation.RequiresApi
import dagger.hilt.android.scopes.ViewModelScoped
import com.zodiactap.mapper.common.utils.Clock
import com.zodiactap.mapper.common.utils.KMResult
import com.zodiactap.mapper.common.utils.firstBlocking
import com.zodiactap.mapper.data.Keys
import com.zodiactap.mapper.data.PreferenceDefaults
import com.zodiactap.mapper.data.repositories.PreferenceRepository
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionManager
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionState
import com.zodiactap.mapper.sysbridge.service.SystemBridgeSetupController
import com.zodiactap.mapper.sysbridge.service.SystemBridgeSetupStep
import com.zodiactap.mapper.system.accessibility.AccessibilityServiceAdapter
import com.zodiactap.mapper.system.accessibility.AccessibilityServiceState
import com.zodiactap.mapper.system.network.NetworkAdapter
import com.zodiactap.mapper.system.permissions.Permission
import com.zodiactap.mapper.system.permissions.PermissionAdapter
import com.zodiactap.mapper.system.root.SuAdapter
import com.zodiactap.mapper.system.shizuku.ShizukuAdapter
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

@OptIn(ExperimentalCoroutinesApi::class)
@ViewModelScoped
class SystemBridgeSetupUseCaseImpl @Inject constructor(
    private val preferences: PreferenceRepository,
    private val suAdapter: SuAdapter,
    private val systemBridgeSetupController: SystemBridgeSetupController,
    private val systemBridgeConnectionManager: SystemBridgeConnectionManager,
    private val shizukuAdapter: ShizukuAdapter,
    private val permissionAdapter: PermissionAdapter,
    private val accessibilityServiceAdapter: AccessibilityServiceAdapter,
    private val networkAdapter: NetworkAdapter,
    private val clock: Clock,
) : SystemBridgeSetupUseCase {

    companion object {
        /**
         * This is specified in android/hardware/usb/UsbManager.java and called
         * FUNCTION_NONE in that file.
         */
        private const val USB_FUNCTION_NONE = 0
    }

    override val isWarningUnderstood: Flow<Boolean> =
        preferences.get(Keys.isExpertModeWarningUnderstood).map { it ?: false }

    private val adbAutoStartEligibility: Flow<AdbAutoStartEligibility> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            combine(
                permissionAdapter.isGrantedFlow(Permission.WRITE_SECURE_SETTINGS),
                networkAdapter.isWifiConnected,
            ) { isWriteSecureSettingsGranted, isWifiConnected ->
                isWriteSecureSettingsGranted && isWifiConnected
            }.flatMapLatest { canCheck ->
                if (canCheck) {
                    flow {
                        emit(AdbAutoStartEligibility.CHECKING)
                        if (systemBridgeSetupController.isAdbPaired()) {
                            emit(AdbAutoStartEligibility.ELIGIBLE)
                        } else {
                            emit(AdbAutoStartEligibility.NOT_ELIGIBLE)
                        }
                    }
                } else {
                    flowOf(AdbAutoStartEligibility.NOT_ELIGIBLE)
                }
            }
        } else {
            flowOf(AdbAutoStartEligibility.NOT_ELIGIBLE)
        }

    override fun onUnderstoodWarning() {
        preferences.set(Keys.isExpertModeWarningUnderstood, true)
    }

    override val isSetupAssistantEnabled: Flow<Boolean> =
        preferences.get(Keys.isExpertModeInteractiveSetupAssistantEnabled).map {
            it ?: PreferenceDefaults.EXPERT_MODE_INTERACTIVE_SETUP_ASSISTANT
        }

    override fun toggleSetupAssistant() {
        preferences.update(Keys.isExpertModeInteractiveSetupAssistantEnabled) {
            if (it == null) {
                !PreferenceDefaults.EXPERT_MODE_INTERACTIVE_SETUP_ASSISTANT
            } else {
                !it
            }
        }
    }

    override val isSystemBridgeConnected: Flow<Boolean> =
        systemBridgeConnectionManager.connectionState
            .map { it is SystemBridgeConnectionState.Connected }

    override val isSystemBridgeStarting: Flow<Boolean> =
        systemBridgeSetupController.isStarting

    override val showStartError: Flow<Unit> =
        systemBridgeSetupController.showStartError

    override val isNotificationPermissionGranted: Flow<Boolean> =
        permissionAdapter.isGrantedFlow(Permission.POST_NOTIFICATIONS)

    @OptIn(ExperimentalCoroutinesApi::class)
    @RequiresApi(Build.VERSION_CODES.R)
    override val nextSetupStep: Flow<SystemBridgeSetupStep> =
        isSystemBridgeConnected.flatMapLatest { isConnected ->
            if (isConnected) {
                flowOf(SystemBridgeSetupStep.STARTED)
            } else {
                adbAutoStartEligibility.flatMapLatest { adbAutoStartEligibility ->
                    when (adbAutoStartEligibility) {
                        AdbAutoStartEligibility.ELIGIBLE ->
                            flowOf(SystemBridgeSetupStep.START_SERVICE)

                        AdbAutoStartEligibility.CHECKING -> emptyFlow()

                        AdbAutoStartEligibility.NOT_ELIGIBLE -> combine(
                            accessibilityServiceAdapter.state,
                            isNotificationPermissionGranted,
                            systemBridgeSetupController.isDeveloperOptionsEnabled,
                            networkAdapter.isWifiConnected,
                            systemBridgeSetupController.isWirelessDebuggingEnabled,
                            ::getNextStep,
                        )
                    }
                }
            }
        }

    override val isRootGranted: Flow<Boolean> = suAdapter.isRootGranted.map { it ?: false }

    override val shizukuSetupState: Flow<ShizukuSetupState> = combine(
        shizukuAdapter.isInstalled,
        shizukuAdapter.isStarted,
        permissionAdapter.isGrantedFlow(Permission.SHIZUKU),
    ) { isInstalled, isStarted, isPermissionGranted ->
        when {
            isPermissionGranted -> ShizukuSetupState.PERMISSION_GRANTED
            isStarted -> ShizukuSetupState.STARTED
            isInstalled -> ShizukuSetupState.INSTALLED
            else -> ShizukuSetupState.NOT_FOUND
        }
    }

    override fun openShizukuApp() {
        shizukuAdapter.openShizukuApp()
    }

    override fun requestShizukuPermission() {
        permissionAdapter.request(Permission.SHIZUKU)
    }

    override fun requestNotificationPermission() {
        permissionAdapter.request(Permission.POST_NOTIFICATIONS)
    }

    override fun stopSystemBridge() {
        // Save that they've stopped the system bridge so when the app process launches again
        // it will set the isStoppedByUser to true.
        preferences.set(Keys.isSystemBridgeStoppedByUser, true)

        systemBridgeConnectionManager.stopSystemBridge()
    }

    override fun enableAccessibilityService() {
        accessibilityServiceAdapter.start()
    }

    override fun enableDeveloperOptions() {
        systemBridgeSetupController.enableDeveloperOptions()
    }

    override fun launchDeveloperOptions() {
        systemBridgeSetupController.launchDeveloperOptions()
    }

    override val xiaomiAdbSecuritySettingsEnabled: Flow<Boolean> =
        systemBridgeSetupController.xiaomiAdbSecuritySettingsEnabled

    override fun connectWifiNetwork() {
        networkAdapter.connectWifiNetwork()
    }

    override fun enableWirelessDebugging() {
        systemBridgeSetupController.enableWirelessDebugging()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun pairWirelessAdb() {
        systemBridgeSetupController.launchPairingAssistant()
    }

    override fun startSystemBridgeWithRoot() {
        startSystemBridge {
            systemBridgeSetupController.startWithRoot()
        }
    }

    override fun startSystemBridgeWithShizuku() {
        startSystemBridge { systemBridgeSetupController.startWithShizuku() }
    }

    override fun startSystemBridgeWithAdb() {
        startSystemBridge {
            systemBridgeSetupController.startWithAdb()
        }
    }

    override fun autoStartSystemBridgeWithAdb() {
        systemBridgeSetupController.autoStartWithAdb()
    }

    private fun startSystemBridge(block: () -> Unit) {
        preferences.set(Keys.systemBridgeLastManualStartTime, clock.unixTimestamp())
        preferences.set(Keys.isSystemBridgeEmergencyKilled, false)
        preferences.set(Keys.isSystemBridgeStoppedByUser, false)
        block.invoke()
    }

    override fun isInfoDismissed(): Boolean {
        return preferences.get(Keys.isExpertModeInfoDismissed).map { it ?: false }.firstBlocking()
    }

    override fun dismissInfo() {
        preferences.set(Keys.isExpertModeInfoDismissed, true)
    }

    override val isAutoStartBootAllowed: Flow<Boolean> =
        permissionAdapter.isGrantedFlow(Permission.ROOT).flatMapLatest { isRooted ->
            if (isRooted) {
                flowOf(true)
            } else {
                permissionAdapter.isGrantedFlow(Permission.WRITE_SECURE_SETTINGS)
            }
        }

    override val isAutoStartBootEnabled: Flow<Boolean> =
        isAutoStartBootAllowed.flatMapLatest { isAllowed ->
            if (isAllowed) {
                preferences.get(Keys.isSystemBridgeKeepAliveEnabled)
                    .map { it ?: PreferenceDefaults.EXPERT_MODE_KEEP_ALIVE }
            } else {
                flowOf(false)
            }
        }

    override fun toggleAutoStartBoot() {
        preferences.update(Keys.isSystemBridgeKeepAliveEnabled) {
            !(it ?: PreferenceDefaults.EXPERT_MODE_KEEP_ALIVE)
        }
    }

    override val isEmergencyStopEnabled: Flow<Boolean> =
        preferences.get(Keys.isSystemBridgeEmergencyStopEnabled)
            .map { it ?: PreferenceDefaults.SYSTEM_BRIDGE_EMERGENCY_STOP_ENABLED }

    override fun toggleEmergencyStop() {
        preferences.update(Keys.isSystemBridgeEmergencyStopEnabled) {
            !(it ?: PreferenceDefaults.SYSTEM_BRIDGE_EMERGENCY_STOP_ENABLED)
        }
    }

    /**
     * This applies to older Android versions (tested on Android 11 and 13).
     * Having the "Default USB Configuration" in developer options set to something other
     * than "No data transfer" causes the system bridge (ADB) process to be killed when the device
     * is locked. Not 100% sure what the mechanic is but it can be reproduced by pressing the
     * power button. On Android 15 this is not the case because it seems like turning on
     * wireless debugging or ADB resets the setting to "No data transfer".
     */
    override fun isCompatibleUsbModeSelected(): KMResult<Boolean> {
        return systemBridgeConnectionManager
            .run { systemBridge ->
                // The USB setting does not matter if the system bridge is running as root
                // because it doesn't rely on the ADB process.
                systemBridge.processUid == Process.ROOT_UID ||
                    systemBridge.usbScreenUnlockedFunctions.toInt() == 0
            }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun getNextStep(
        accessibilityServiceState: AccessibilityServiceState,
        isNotificationPermissionGranted: Boolean,
        isDeveloperOptionsEnabled: Boolean,
        isWifiConnected: Boolean,
        isWirelessDebuggingEnabled: Boolean,
    ): SystemBridgeSetupStep {
        return when {
            accessibilityServiceState != AccessibilityServiceState.ENABLED ->
                SystemBridgeSetupStep.ACCESSIBILITY_SERVICE

            !isNotificationPermissionGranted -> SystemBridgeSetupStep.NOTIFICATION_PERMISSION

            !isDeveloperOptionsEnabled -> SystemBridgeSetupStep.DEVELOPER_OPTIONS

            !isWifiConnected -> SystemBridgeSetupStep.WIFI_NETWORK

            !isWirelessDebuggingEnabled -> SystemBridgeSetupStep.WIRELESS_DEBUGGING

            isWirelessDebuggingEnabled -> SystemBridgeSetupStep.ADB_PAIRING

            else -> SystemBridgeSetupStep.START_SERVICE
        }
    }

    override suspend fun getShellStartCommand(): KMResult<String> {
        return systemBridgeSetupController.getShellStartCommand()
    }
}

interface SystemBridgeSetupUseCase {
    val isWarningUnderstood: Flow<Boolean>
    fun onUnderstoodWarning()

    fun isInfoDismissed(): Boolean
    fun dismissInfo()

    val isAutoStartBootEnabled: Flow<Boolean>
    val isAutoStartBootAllowed: Flow<Boolean>
    fun toggleAutoStartBoot()

    val isEmergencyStopEnabled: Flow<Boolean>
    fun toggleEmergencyStop()

    val isSetupAssistantEnabled: Flow<Boolean>
    fun toggleSetupAssistant()

    val isSystemBridgeConnected: Flow<Boolean>
    val isSystemBridgeStarting: Flow<Boolean>
    val showStartError: Flow<Unit>
    val nextSetupStep: Flow<SystemBridgeSetupStep>

    val isRootGranted: Flow<Boolean>

    val shizukuSetupState: Flow<ShizukuSetupState>
    fun openShizukuApp()
    fun requestShizukuPermission()

    val isNotificationPermissionGranted: Flow<Boolean>
    fun requestNotificationPermission()

    fun stopSystemBridge()
    fun enableAccessibilityService()
    fun enableDeveloperOptions()
    fun launchDeveloperOptions()
    fun connectWifiNetwork()
    fun enableWirelessDebugging()
    fun pairWirelessAdb()
    fun startSystemBridgeWithRoot()
    fun startSystemBridgeWithShizuku()
    fun startSystemBridgeWithAdb()
    fun autoStartSystemBridgeWithAdb()

    val xiaomiAdbSecuritySettingsEnabled: Flow<Boolean>

    fun isCompatibleUsbModeSelected(): KMResult<Boolean>

    suspend fun getShellStartCommand(): KMResult<String>
}

enum class AdbAutoStartEligibility {
    ELIGIBLE,
    CHECKING,
    NOT_ELIGIBLE,
}
