package com.zodiactap.mapper.base.actions.keyevent

import android.annotation.SuppressLint
import android.view.KeyEvent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import com.zodiactap.mapper.base.R
import com.zodiactap.mapper.base.actions.ActionData
import com.zodiactap.mapper.base.utils.KeyCodeStrings
import com.zodiactap.mapper.base.utils.getFullMessage
import com.zodiactap.mapper.base.utils.navigation.NavDestination
import com.zodiactap.mapper.base.utils.navigation.NavigationProvider
import com.zodiactap.mapper.base.utils.navigation.NavigationProviderImpl
import com.zodiactap.mapper.base.utils.navigation.navigate
import com.zodiactap.mapper.base.utils.ui.CheckBoxListItem
import com.zodiactap.mapper.base.utils.ui.ResourceProvider
import com.zodiactap.mapper.common.utils.InputDeviceInfo
import com.zodiactap.mapper.common.utils.InputDeviceUtils
import com.zodiactap.mapper.common.utils.KMError
import com.zodiactap.mapper.common.utils.KMResult
import com.zodiactap.mapper.common.utils.Success
import com.zodiactap.mapper.common.utils.errorOrNull
import com.zodiactap.mapper.common.utils.handle
import com.zodiactap.mapper.common.utils.hasFlag
import com.zodiactap.mapper.common.utils.isSuccess
import com.zodiactap.mapper.common.utils.minusFlag
import com.zodiactap.mapper.common.utils.success
import com.zodiactap.mapper.common.utils.valueOrNull
import com.zodiactap.mapper.common.utils.withFlag
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class ConfigKeyEventActionViewModel @Inject constructor(
    private val useCase: ConfigKeyEventUseCase,
    private val resourceProvider: ResourceProvider,
) : ViewModel(),
    ResourceProvider by resourceProvider,
    NavigationProvider by NavigationProviderImpl() {

    private val keyEventState = MutableStateFlow(KeyEventState())

    val uiState: StateFlow<ConfigKeyEventUiState> = combine(
        keyEventState,
        useCase.inputDevices,
        useCase.showDeviceDescriptors,
    ) { state, inputDevices, showDeviceDescriptors ->
        buildUiState(state, inputDevices, showDeviceDescriptors)
    }.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        buildUiState(
            keyEventState.value,
            inputDeviceList = emptyList(),
            showDeviceDescriptors = false,
        ),
    )

    private val _returnResult = MutableSharedFlow<ActionData.InputKeyEvent>()
    val returnResult = _returnResult.asSharedFlow()

    fun setModifierKeyChecked(modifier: Int, isChecked: Boolean) {
        val oldMetaState = keyEventState.value.metaState

        if (isChecked) {
            keyEventState.value = keyEventState.value.copy(
                metaState = oldMetaState.withFlag(modifier),
            )
        } else {
            keyEventState.value = keyEventState.value.copy(
                metaState = oldMetaState.minusFlag(modifier),
            )
        }
    }

    fun onChooseKeyCodeClick() {
        viewModelScope.launch {
            val keyCode = navigate("choose_key_code_for_key_event", NavDestination.ChooseKeyCode)
                ?: return@launch

            setKeyCode(keyCode)
        }
    }

    fun setKeyCode(keyCode: Int) {
        keyEventState.value = keyEventState.value.copy(keyCode = Success(keyCode))
    }

    fun loadAction(action: ActionData.InputKeyEvent) {
        viewModelScope.launch {
            val inputDevice = useCase.inputDevices.first().find {
                it.descriptor == action.device?.descriptor &&
                    it.name == action.device.name
            }

            keyEventState.value = KeyEventState(
                Success(action.keyCode),
                inputDevice,
                metaState = action.metaState,
            )
        }
    }

    fun onKeyCodeTextChanged(text: String) {
        val keyCodeState = when {
            text.isBlank() -> KMError.EmptyText
            text.toIntOrNull() == null -> KMError.InvalidNumber
            else -> text.toInt().success()
        }

        keyEventState.value = keyEventState.value.copy(keyCode = keyCodeState)
    }

    @SuppressLint("NullSafeMutableLiveData")
    fun chooseNoDevice() {
        keyEventState.value = keyEventState.value.copy(chosenDevice = null)
    }

    fun chooseDevice(index: Int) {
        val chosenDevice = uiState.value.deviceListItems.getOrNull(index)

        if (chosenDevice == null) {
            return
        }

        keyEventState.value = keyEventState.value.copy(
            chosenDevice = chosenDevice,
        )
    }

    fun onDoneClick() {
        viewModelScope.launch {
            val keyCode = keyEventState.value.keyCode.valueOrNull() ?: return@launch

            val device = keyEventState.value.chosenDevice?.let {
                ActionData.InputKeyEvent.Device(
                    descriptor = it.descriptor,
                    name = it.name,
                )
            }

            _returnResult.emit(
                ActionData.InputKeyEvent(
                    keyCode = keyCode,
                    metaState = keyEventState.value.metaState,
                    device = device,
                ),
            )
        }
    }

    private fun buildUiState(
        state: KeyEventState,
        inputDeviceList: List<InputDeviceInfo>,
        showDeviceDescriptors: Boolean,
    ): ConfigKeyEventUiState {
        val keyCode = state.keyCode
        val metaState = state.metaState
        val chosenDevice = state.chosenDevice

        val keyCodeString = when (keyCode) {
            is Success -> keyCode.value.toString()
            else -> ""
        }

        val keyCodeLabel = keyCode.handle(
            onSuccess = {
                if (it > KeyEvent.getMaxKeyCode()) {
                    "Key Code $it"
                } else {
                    KeyEvent.keyCodeToString(it)
                }
            },
            onError = { "" },
        )

        val modifierListItems = KeyCodeStrings.MODIFIER_LABELS.map { (modifier, label) ->
            CheckBoxListItem(
                id = modifier.toString(),
                label = getString(label),
                isChecked = metaState.hasFlag(modifier),
            )
        }

        val deviceListItems = inputDeviceList.map { device ->
            if (showDeviceDescriptors) {
                device.copy(
                    name = InputDeviceUtils.appendDeviceDescriptorToName(
                        device.descriptor,
                        device.name,
                    ),
                )
            } else {
                device
            }
        }

        val chosenDeviceName: String = when {
            chosenDevice == null -> getString(R.string.from_no_device)
            showDeviceDescriptors -> InputDeviceUtils.appendDeviceDescriptorToName(
                chosenDevice.descriptor,
                chosenDevice.name,
            )

            else -> chosenDevice.name
        }

        return ConfigKeyEventUiState(
            keyCodeString = keyCodeString,
            keyCodeErrorMessage = keyCode.errorOrNull()?.getFullMessage(this),
            keyCodeLabel = keyCodeLabel,
            showKeyCodeLabel = keyCode.isSuccess,
            isDevicePickerShown = true,
            isModifierListShown = true,
            modifierListItems = modifierListItems,
            isDoneButtonEnabled = keyCode.isSuccess,
            deviceListItems = deviceListItems,
            chosenDeviceName = chosenDeviceName,
        )
    }

    private data class KeyEventState(
        val keyCode: KMResult<Int> = KMError.EmptyText,
        val chosenDevice: InputDeviceInfo? = null,
        val metaState: Int = 0,
    )
}

data class ConfigKeyEventUiState(
    val keyCodeString: String,
    val keyCodeErrorMessage: String?,
    val keyCodeLabel: String,
    val showKeyCodeLabel: Boolean,
    val isDevicePickerShown: Boolean,
    val isModifierListShown: Boolean,
    val modifierListItems: List<CheckBoxListItem>,
    val isDoneButtonEnabled: Boolean,
    val deviceListItems: List<InputDeviceInfo>,
    val chosenDeviceName: String,
)
