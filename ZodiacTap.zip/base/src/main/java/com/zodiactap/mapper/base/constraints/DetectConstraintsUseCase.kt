package com.zodiactap.mapper.base.constraints

import android.os.Build
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import com.zodiactap.mapper.base.system.accessibility.IAccessibilityService
import com.zodiactap.mapper.system.camera.CameraAdapter
import com.zodiactap.mapper.system.camera.CameraLens
import com.zodiactap.mapper.system.devices.DevicesAdapter
import com.zodiactap.mapper.system.display.DisplayAdapter
import com.zodiactap.mapper.system.foldable.FoldableAdapter
import com.zodiactap.mapper.system.inputmethod.InputMethodAdapter
import com.zodiactap.mapper.system.lock.LockScreenAdapter
import com.zodiactap.mapper.system.media.MediaAdapter
import com.zodiactap.mapper.system.network.NetworkAdapter
import com.zodiactap.mapper.system.phone.PhoneAdapter
import com.zodiactap.mapper.system.power.PowerAdapter
import com.zodiactap.mapper.system.volume.VolumeAdapter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge

class DetectConstraintsUseCaseImpl @AssistedInject constructor(
    @Assisted
    private val accessibilityService: IAccessibilityService,
    private val mediaAdapter: MediaAdapter,
    private val devicesAdapter: DevicesAdapter,
    private val displayAdapter: DisplayAdapter,
    private val cameraAdapter: CameraAdapter,
    private val networkAdapter: NetworkAdapter,
    private val inputMethodAdapter: InputMethodAdapter,
    private val lockScreenAdapter: LockScreenAdapter,
    private val phoneAdapter: PhoneAdapter,
    private val powerAdapter: PowerAdapter,
    private val foldableAdapter: FoldableAdapter,
    private val volumeAdapter: VolumeAdapter,
) : DetectConstraintsUseCase {

    @AssistedFactory
    interface Factory {
        fun create(accessibilityService: IAccessibilityService): DetectConstraintsUseCaseImpl
    }

    override fun getSnapshot(): ConstraintSnapshot = LazyConstraintSnapshot(
        accessibilityService,
        mediaAdapter,
        devicesAdapter,
        displayAdapter,
        networkAdapter,
        cameraAdapter,
        inputMethodAdapter,
        lockScreenAdapter,
        phoneAdapter,
        powerAdapter,
        foldableAdapter,
        volumeAdapter,
    )

    override fun onDependencyChanged(dependency: ConstraintDependency): Flow<ConstraintDependency> {
        return when (dependency) {
            ConstraintDependency.FOREGROUND_APP -> accessibilityService.activeWindowPackage.map {
                dependency
            }

            ConstraintDependency.APP_PLAYING_MEDIA, ConstraintDependency.MEDIA_PLAYING ->
                merge(
                    mediaAdapter.getActiveMediaSessionPackagesFlow(),
                    mediaAdapter.getActiveAudioVolumeStreamsFlow(),
                ).map { dependency }

            ConstraintDependency.CONNECTED_BT_DEVICES ->
                devicesAdapter.connectedBluetoothDevices.map { dependency }

            ConstraintDependency.SCREEN_STATE -> displayAdapter.isScreenOn.map { dependency }

            ConstraintDependency.DISPLAY_ORIENTATION ->
                displayAdapter.orientation.map { dependency }

            ConstraintDependency.PHYSICAL_ORIENTATION ->
                displayAdapter.physicalOrientation.map { dependency }

            ConstraintDependency.FLASHLIGHT_STATE -> merge(
                cameraAdapter.isFlashlightOnFlow(CameraLens.FRONT),
                cameraAdapter.isFlashlightOnFlow(CameraLens.BACK),
            ).map { dependency }

            ConstraintDependency.WIFI_SSID ->
                networkAdapter.connectedWifiSSIDFlow.map { dependency }

            ConstraintDependency.WIFI_STATE -> networkAdapter.isWifiEnabledFlow().map { dependency }

            ConstraintDependency.CHOSEN_IME -> inputMethodAdapter.chosenIme.map { dependency }

            ConstraintDependency.DEVICE_LOCKED_STATE ->
                lockScreenAdapter.isLockedFlow().map { dependency }

            ConstraintDependency.LOCK_SCREEN_SHOWING ->
                merge(
                    lockScreenAdapter.isLockScreenShowingFlow(),
                    accessibilityService.activeWindowPackage,
                ).map { dependency }

            ConstraintDependency.PHONE_STATE -> phoneAdapter.callStateFlow.map { dependency }

            ConstraintDependency.RINGER_MODE -> volumeAdapter.ringerModeFlow.map { dependency }

            ConstraintDependency.CHARGING_STATE -> powerAdapter.isCharging.map { dependency }

            ConstraintDependency.HINGE_STATE ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    foldableAdapter.hingeState.map { dependency }
                } else {
                    emptyFlow()
                }

            ConstraintDependency.KEYBOARD_VISIBLE ->
                accessibilityService.isInputMethodVisible.map { dependency }

            ConstraintDependency.NOTIFICATION_PANEL_STATE ->
                accessibilityService.isNotificationShadeExpanded.map { dependency }

            ConstraintDependency.DISPLAY_RESOLUTIONS -> displayAdapter.supportedResolutions.map {
                dependency
            }
        }
    }
}

interface DetectConstraintsUseCase {
    fun getSnapshot(): ConstraintSnapshot
    fun onDependencyChanged(dependency: ConstraintDependency): Flow<ConstraintDependency>
}
