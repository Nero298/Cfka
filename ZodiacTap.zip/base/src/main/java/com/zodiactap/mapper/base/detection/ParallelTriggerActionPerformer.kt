package com.zodiactap.mapper.base.detection

import com.zodiactap.mapper.base.actions.Action
import com.zodiactap.mapper.base.actions.ActionData
import com.zodiactap.mapper.base.actions.PerformActionTriggerDevice
import com.zodiactap.mapper.base.actions.PerformActionsUseCase
import com.zodiactap.mapper.base.actions.RepeatMode
import com.zodiactap.mapper.common.utils.InputEventAction
import com.zodiactap.mapper.data.PreferenceDefaults
import com.zodiactap.mapper.system.inputevents.KeyEventUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ParallelTriggerActionPerformer(
    private val coroutineScope: CoroutineScope,
    private val useCase: PerformActionsUseCase,
    private val actionList: List<Action>,
) {
    private var actionIsHeldDown = BooleanArray(actionList.size) { false }

    private var repeatJobs = Array<Job?>(actionList.size) { null }
    private var performActionsJob: Job? = null

    private val defaultHoldDownDuration: StateFlow<Long> =
        useCase.defaultHoldDownDuration.stateIn(
            coroutineScope,
            SharingStarted.Eagerly,
            PreferenceDefaults.HOLD_DOWN_DURATION.toLong(),
        )

    private val defaultRepeatDelay: StateFlow<Long> =
        useCase.defaultRepeatDelay.stateIn(
            coroutineScope,
            SharingStarted.Eagerly,
            PreferenceDefaults.REPEAT_DELAY.toLong(),
        )

    private val defaultRepeatRate: StateFlow<Long> =
        useCase.defaultRepeatRate.stateIn(
            coroutineScope,
            SharingStarted.Eagerly,
            PreferenceDefaults.REPEAT_RATE.toLong(),
        )

    fun onTriggered(
        calledOnTriggerRelease: Boolean,
        metaState: Int,
        device: PerformActionTriggerDevice,
    ) {
        performActionsJob?.cancel()
        /*
        this job shouldn't be cancelled when the trigger is released. all actions should be performed
        once before repeating (if configured).
         */
        performActionsJob = coroutineScope.launch {
            for ((actionIndex, action) in actionList.withIndex()) {
                var performUpAction = false

                if (action.holdDown &&
                    action.repeat &&
                    action.repeatMode == RepeatMode.TRIGGER_PRESSED_AGAIN
                ) {
                    if (actionIsHeldDown[actionIndex]) {
                        actionIsHeldDown[actionIndex] = false
                        performUpAction = true
                    }
                }

                if (action.stopHoldDownWhenTriggerPressedAgain) {
                    if (actionIsHeldDown[actionIndex]) {
                        actionIsHeldDown[actionIndex] = false
                        performUpAction = true
                    }
                }

                if (action.holdDown && !performUpAction) {
                    actionIsHeldDown[actionIndex] = true
                }

                val actionInputEventAction = when {
                    performUpAction -> InputEventAction.UP
                    action.holdDown -> InputEventAction.DOWN
                    else -> InputEventAction.DOWN_UP
                }

                performAction(action, actionInputEventAction, metaState, device)

                if (action.repeat && action.holdDown) {
                    delay(action.holdDownDuration?.toLong() ?: defaultHoldDownDuration.value)
                }

                delay(action.delayBeforeNextAction?.toLong() ?: 0L)
            }
        }

        for (job in repeatJobs) {
            job?.cancel()
        }

        for ((actionIndex, action) in actionList.withIndex()) {
            if (!action.repeat) {
                continue
            }

            if (calledOnTriggerRelease && action.repeatMode == RepeatMode.TRIGGER_RELEASED) {
                continue
            }

            // don't start repeating if it is already repeating
            if (action.repeatMode == RepeatMode.TRIGGER_PRESSED_AGAIN &&
                repeatJobs[actionIndex] != null
            ) {
                repeatJobs[actionIndex]?.cancel()
                repeatJobs[actionIndex] = null

                continue
            }

            if (action.data is ActionData.InputKeyEvent &&
                KeyEventUtils.isModifierKey(action.data.keyCode)
            ) {
                continue
            }

            repeatJobs[actionIndex] = coroutineScope.launch {
                var continueRepeating = true
                var repeatCount = 0

                delay(action.repeatDelay?.toLong() ?: defaultRepeatDelay.value)

                while (isActive && continueRepeating) {
                    if (action.holdDown) {
                        performAction(action, InputEventAction.DOWN, metaState, device)
                        delay(
                            action.holdDownDuration?.toLong() ?: defaultHoldDownDuration.value,
                        )
                        performAction(action, InputEventAction.UP, metaState, device)
                    } else {
                        performAction(action, InputEventAction.DOWN_UP, metaState, device)
                    }

                    repeatCount++

                    if (action.repeatLimit != null) {
                        continueRepeating = repeatCount < action.repeatLimit
                    }

                    delay(action.repeatRate?.toLong() ?: defaultRepeatRate.value)
                }
            }
        }
    }

    fun onReleased(metaState: Int, device: PerformActionTriggerDevice) {
        repeatJobs.forEachIndexed { actionIndex, job ->
            if (actionList[actionIndex].repeatMode == RepeatMode.TRIGGER_RELEASED) {
                job?.cancel()
                repeatJobs[actionIndex] = null
            }
        }

        coroutineScope.launch {
            for ((actionIndex, action) in actionList.withIndex()) {
                if (action.holdDown && !action.stopHoldDownWhenTriggerPressedAgain) {
                    if (actionIsHeldDown[actionIndex]) {
                        actionIsHeldDown[actionIndex] = false

                        performAction(action, InputEventAction.UP, metaState, device)
                    }
                }
            }
        }
    }

    fun reset() {
        performActionsJob?.cancel()
        performActionsJob = null

        coroutineScope.launch {
            for ((index, isHeldDown) in actionIsHeldDown.withIndex()) {
                if (isHeldDown) {
                    performAction(
                        actionList[index],
                        inputEventAction = InputEventAction.UP,
                        0,
                        PerformActionTriggerDevice.Default,
                    )
                }
            }
        }

        actionIsHeldDown.indices.forEach {
            actionIsHeldDown[it] = false
        }

        repeatJobs.indices.forEach {
            repeatJobs[it]?.cancel()
            repeatJobs[it] = null
        }
    }

    private suspend fun performAction(
        action: Action,
        inputEventAction: InputEventAction,
        metaState: Int,
        device: PerformActionTriggerDevice,
    ) {
        repeat(action.multiplier ?: 1) {
            useCase.perform(action.data, inputEventAction, metaState, device)
        }
    }
}
