package com.zodiactap.mapper.base.actions

import android.view.KeyEvent
import com.zodiactap.mapper.base.repositories.FakePreferenceRepository
import com.zodiactap.mapper.base.system.inputmethod.FakeInputMethodAdapter
import com.zodiactap.mapper.base.utils.TestBuildConfigProvider
import com.zodiactap.mapper.common.utils.KMError
import com.zodiactap.mapper.common.utils.Success
import com.zodiactap.mapper.data.Keys
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionManager
import com.zodiactap.mapper.sysbridge.manager.SystemBridgeConnectionState
import com.zodiactap.mapper.sysbridge.utils.SystemBridgeError
import com.zodiactap.mapper.system.apps.PackageManagerAdapter
import com.zodiactap.mapper.system.inputmethod.ImeInfo
import com.zodiactap.mapper.system.permissions.Permission
import com.zodiactap.mapper.system.permissions.PermissionAdapter
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.`is`
import org.hamcrest.Matchers.nullValue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.junit.MockitoJUnitRunner
import org.mockito.kotlin.mock
import org.mockito.kotlin.whenever

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class GetActionErrorUseCaseTest {

    companion object {
        private val GUI_KEYBOARD_IME_INFO = ImeInfo(
            id = "ime_id",
            packageName = "com.zodiactap.mapper.inputmethod.latin",
            label = "Key Mapper GUI Keyboard",
            isEnabled = true,
            isChosen = true,
        )

        private val GBOARD_IME_INFO = ImeInfo(
            id = "gboard_id",
            packageName = "com.google.android.inputmethod.latin",
            label = "Gboard",
            isEnabled = true,
            isChosen = false,
        )
    }

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)

    private lateinit var useCase: GetActionErrorUseCaseImpl

    private lateinit var fakeInputMethodAdapter: FakeInputMethodAdapter
    private lateinit var mockPermissionAdapter: PermissionAdapter
    private lateinit var fakePreferenceRepository: FakePreferenceRepository
    private lateinit var mockSystemBridgeConnectionManager: SystemBridgeConnectionManager
    private lateinit var mockPackageManagerAdapter: PackageManagerAdapter

    @Before
    fun init() {
        fakeInputMethodAdapter = FakeInputMethodAdapter()
        mockPermissionAdapter = mock()
        fakePreferenceRepository = FakePreferenceRepository()
        mockSystemBridgeConnectionManager = mock()
        mockPackageManagerAdapter = mock()

        useCase = GetActionErrorUseCaseImpl(
            packageManagerAdapter = mockPackageManagerAdapter,
            inputMethodAdapter = fakeInputMethodAdapter,
            switchImeInterface = mock(),
            permissionAdapter = mockPermissionAdapter,
            systemFeatureAdapter = mock(),
            cameraAdapter = mock(),
            soundsManager = mock(),
            ringtoneAdapter = mock(),
            buildConfigProvider = TestBuildConfigProvider(sdkInt = 36),
            systemBridgeConnectionManager = mockSystemBridgeConnectionManager,
            preferenceRepository = fakePreferenceRepository,
            notificationReceiverAdapter = mock(),
        )
    }

    private fun setupKeyEventActionTest(
        chosenIme: ImeInfo,
        isSystemBridgeUsed: Boolean = false,
        isSystemBridgeConnected: Boolean = false,
    ) {
        whenever(mockPermissionAdapter.isGranted(Permission.WRITE_SECURE_SETTINGS)).then { true }
        fakeInputMethodAdapter.chosenIme.value = chosenIme
        fakeInputMethodAdapter.inputMethods.value = listOf(GBOARD_IME_INFO, GUI_KEYBOARD_IME_INFO)
        fakePreferenceRepository.set(Keys.keyEventActionsUseSystemBridge, isSystemBridgeUsed)

        val connectionState = if (isSystemBridgeConnected) {
            SystemBridgeConnectionState.Connected(time = 0L)
        } else {
            SystemBridgeConnectionState.Disconnected(time = 0L, isStoppedByUser = true)
        }

        whenever(mockSystemBridgeConnectionManager.connectionState).then {
            MutableStateFlow(
                connectionState,
            )
        }
    }

    /**
     * #797, #1719 Allow key maps to have actions that will "fix" subsequent actions in the sequence.
     */
    @Test
    fun `do not show error for key event action if the previous action selects the Key Mapper keyboard`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val actions = listOf(
                ActionData.SwitchKeyboard(
                    imeId = GUI_KEYBOARD_IME_INFO.id,
                    GUI_KEYBOARD_IME_INFO.label,
                ),
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
            assertThat(errors[1], nullValue())
        }

    @Test
    fun `do not show error for text actions if the previous action selects the Key Mapper keyboard`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val actions = listOf(
                ActionData.SwitchKeyboard(
                    imeId = GUI_KEYBOARD_IME_INFO.id,
                    GUI_KEYBOARD_IME_INFO.label,
                ),
                ActionData.Text("hello"),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
            assertThat(errors[1], nullValue())
        }

    @Test
    fun `do not show error for key event actions if an action not immediately before selects the Key Mapper keyboard`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val actions = listOf(
                ActionData.SwitchKeyboard(
                    imeId = GUI_KEYBOARD_IME_INFO.id,
                    GUI_KEYBOARD_IME_INFO.label,
                ),
                ActionData.OpenCamera,
                ActionData.OpenSettings,
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
            assertThat(errors[1], nullValue())
            assertThat(errors[2], nullValue())
            assertThat(errors[3], nullValue())
        }

    @Test
    fun `do not show an error for a key event action if a key mapper keyboard is selected`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GUI_KEYBOARD_IME_INFO)

            val action = ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN)

            val errors = useCase.actionErrorSnapshot.first().getErrors(listOf(action))
            assertThat(errors[action], nullValue())
        }

    @Test
    fun `show an error for a key event action if a key mapper keyboard is not selected`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val action = ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN)

            val errors = useCase.actionErrorSnapshot.first().getErrors(listOf(action))
            assertThat(
                errors[action],
                `is`(KMError.KeyEventActionError(KMError.NoCompatibleImeChosen)),
            )
        }

    @Test
    fun `show an error for a key event action in a list if a key mapper keyboard is not selected`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val actions = listOf(
                ActionData.OpenCamera,
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
            assertThat(errors[1], `is`(KMError.KeyEventActionError(KMError.NoCompatibleImeChosen)))
        }

    @Test
    fun `show an error for a key event action if a previous action selects a non-key mapper keyboard`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val actions = listOf(
                ActionData.SwitchKeyboard(imeId = GBOARD_IME_INFO.id, GBOARD_IME_INFO.label),
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
            assertThat(errors[1], `is`(KMError.KeyEventActionError(KMError.NoCompatibleImeChosen)))
        }

    @Test
    fun `show an error for a key event action if a previous action selects a non-key mapper keyboard after selecting a key mapper keyboard`() =
        testScope.runTest {
            setupKeyEventActionTest(chosenIme = GBOARD_IME_INFO)

            val actions = listOf(
                ActionData.SwitchKeyboard(
                    imeId = GUI_KEYBOARD_IME_INFO.id,
                    GUI_KEYBOARD_IME_INFO.label,
                ),
                ActionData.SwitchKeyboard(imeId = GBOARD_IME_INFO.id, GBOARD_IME_INFO.label),
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
            assertThat(errors[1], nullValue())
            assertThat(errors[2], `is`(KMError.KeyEventActionError(KMError.NoCompatibleImeChosen)))
        }

    @Test
    fun `do not show an error for a key event action if system bridge is connected, pro mode is selected for key event actions, and no key mapper input method is chosen`() =
        testScope.runTest {
            setupKeyEventActionTest(
                chosenIme = GBOARD_IME_INFO,
                isSystemBridgeUsed = true,
                isSystemBridgeConnected = true,
            )

            val actions = listOf(
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], nullValue())
        }

    @Test
    fun `show an error for a key event action if system bridge is disconnected, pro mode is selected for key event actions, and a key mapper input method is chosen`() =
        testScope.runTest {
            setupKeyEventActionTest(
                chosenIme = GUI_KEYBOARD_IME_INFO,
                isSystemBridgeUsed = true,
                isSystemBridgeConnected = false,
            )

            val actions = listOf(
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], `is`(KMError.KeyEventActionError(SystemBridgeError.Disconnected)))
        }

    @Test
    fun `show an error for a key event action if system bridge is disconnected, pro mode is selected for key event actions, and a key mapper input method is not chosen`() =
        testScope.runTest {
            setupKeyEventActionTest(
                chosenIme = GBOARD_IME_INFO,
                isSystemBridgeUsed = true,
                isSystemBridgeConnected = false,
            )

            val actions = listOf(
                ActionData.InputKeyEvent(keyCode = KeyEvent.KEYCODE_VOLUME_DOWN),
            )

            val errors = useCase.actionErrorSnapshot.first().getErrors(actions).values.toList()

            assertThat(errors[0], `is`(KMError.KeyEventActionError(SystemBridgeError.Disconnected)))
        }

    @Test
    fun `show an error for device assistant action when no device assistant is installed`() =
        testScope.runTest {
            whenever(
                mockPackageManagerAdapter.getDeviceAssistantPackage(),
            ).thenReturn(KMError.NoDeviceAssistant)

            val action = ActionData.DeviceAssistant

            val errors = useCase.actionErrorSnapshot.first().getErrors(listOf(action))

            assertThat(errors[action], `is`(KMError.NoDeviceAssistant))
        }

    @Test
    fun `do not show an error for device assistant action when a device assistant is installed`() =
        testScope.runTest {
            whenever(
                mockPackageManagerAdapter.getDeviceAssistantPackage(),
            ).thenReturn(Success("com.google.android.googlequicksearchbox"))

            val action = ActionData.DeviceAssistant

            val errors = useCase.actionErrorSnapshot.first().getErrors(listOf(action))

            assertThat(errors[action], nullValue())
        }
}
