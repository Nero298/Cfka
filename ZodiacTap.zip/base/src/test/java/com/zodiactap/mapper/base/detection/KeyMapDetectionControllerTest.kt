package com.zodiactap.mapper.base.detection

import android.view.KeyEvent
import com.zodiactap.mapper.base.actions.Action
import com.zodiactap.mapper.base.actions.ActionData
import com.zodiactap.mapper.base.keymaps.ClickType
import com.zodiactap.mapper.base.keymaps.KeyMap
import com.zodiactap.mapper.base.trigger.EvdevTriggerKey
import com.zodiactap.mapper.base.trigger.KeyEventTriggerDevice
import com.zodiactap.mapper.base.trigger.KeyEventTriggerKey
import com.zodiactap.mapper.base.trigger.Trigger
import com.zodiactap.mapper.base.utils.parallelTrigger
import com.zodiactap.mapper.base.utils.singleKeyTrigger
import com.zodiactap.mapper.common.models.EvdevDeviceInfo
import com.zodiactap.mapper.common.models.GrabTargetKeyCode
import com.zodiactap.mapper.system.inputevents.Scancode
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.contains
import org.hamcrest.collection.IsEmptyCollection.empty
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.mockito.MockedStatic
import org.mockito.Mockito.mockStatic
import org.mockito.kotlin.mock

@OptIn(ExperimentalCoroutinesApi::class)
class KeyMapDetectionControllerTest {

    companion object {
        private val FAKE_CONTROLLER_EVDEV_DEVICE = EvdevDeviceInfo(
            name = "Fake Controller",
            bus = 1,
            vendor = 2,
            product = 1,
        )

        private val FAKE_CONTROLLER_EVDEV_DEVICE_2 = EvdevDeviceInfo(
            name = "Fake Controller 2",
            bus = 1,
            vendor = 3,
            product = 2,
        )
    }

    private val testDispatcher = UnconfinedTestDispatcher()
    private val testScope = TestScope(testDispatcher)
    private lateinit var algorithm: KeyMapAlgorithm
    private lateinit var mockedKeyEvent: MockedStatic<KeyEvent>

    @Before
    fun init() {
        mockedKeyEvent = mockStatic(KeyEvent::class.java)
        mockedKeyEvent.`when`<Int> { KeyEvent.getMaxKeyCode() }.thenReturn(1000)

        algorithm = KeyMapAlgorithm(
            coroutineScope = testScope,
            useCase = mock(),
            performActionsUseCase = mock(),
            detectConstraints = mock(),
        )
    }

    @After
    fun tearDown() {
        mockedKeyEvent.close()
    }

    @Test
    fun `Only grab the same device once if multiple key maps add key events`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    Action(data = ActionData.OpenCamera),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_Y),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(
                        KeyEvent.KEYCODE_BUTTON_X,
                        KeyEvent.KEYCODE_BUTTON_Y,
                    ),
                ),
            ),
        )
    }

    @Test
    fun `Grab multiple evdev devices from multiple triggers with key event actions`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    Action(data = ActionData.OpenCamera),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_Y),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_X),
                ),
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_Y),
                ),
            ),
        )
    }

    @Test
    fun `Do not grab evdev devices with extra key codes if key event actions do not use system bridge`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    Action(data = ActionData.OpenCamera),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_Y),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(
            algorithm,
            injectKeyEventActionsWithSystemBridge = false,
        )

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(),
                ),
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Grab multiple evdev devices from multiple triggers`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Grab multiple evdev devices from the same trigger`() {
        loadKeyMaps(
            KeyMap(
                trigger = parallelTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Grab evdev device for evdev trigger`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)
        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Do not grab evdev device if key map has no actions`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = emptyList(),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)
        assertThat(grabRequests, empty())
    }

    @Test
    fun `Grab evdev device with extra key codes if action inputs key events`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_B)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_B),
                ),
            ),
        )
    }

    @Test
    fun `Do not grab evdev device for key event trigger`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    KeyEventTriggerKey(
                        keyCode = KeyEvent.KEYCODE_VOLUME_DOWN,
                        clickType = ClickType.SHORT_PRESS,
                        device = KeyEventTriggerDevice.Any,
                    ),
                ),
            ),
        )
        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)
        assertThat(grabRequests, empty())
    }

    @Test
    fun `do not grab any evdev devices if no triggers`() {
        algorithm.loadKeyMaps(emptyList())
        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)
        assertThat(grabRequests, empty())
    }

    // ==================== TRIGGER KEY COMBINATION EDGE CASES ====================

    @Test
    fun `Same key on different devices in parallel trigger should grab both devices`() {
        loadKeyMaps(
            KeyMap(
                trigger = parallelTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Long press trigger should grab device`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.LONG_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Double press trigger should grab device`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.DOUBLE_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Same key with different click types in different key maps should grab device once`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.LONG_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.GoHome)),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.DOUBLE_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.GoBack)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Mixed evdev and key event triggers in parallel should only grab evdev device`() {
        loadKeyMaps(
            KeyMap(
                trigger = parallelTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                    KeyEventTriggerKey(
                        keyCode = KeyEvent.KEYCODE_VOLUME_DOWN,
                        clickType = ClickType.SHORT_PRESS,
                        device = KeyEventTriggerDevice.Any,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    // ==================== ACTION EDGE CASES ====================

    @Test
    fun `Multiple key event actions should add all key codes to extra key codes`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_Y),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_L1),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(
                        KeyEvent.KEYCODE_BUTTON_X,
                        KeyEvent.KEYCODE_BUTTON_Y,
                        KeyEvent.KEYCODE_BUTTON_L1,
                    ),
                ),
            ),
        )
    }

    @Test
    fun `Duplicate key event actions should not duplicate extra key codes`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
        )
    }

    @Test
    fun `Action that inputs same key code as trigger key should include in extra key codes`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_A),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_A),
                ),
            ),
        )
    }

    @Test
    fun `Key map with only non-key-event actions should have empty extra key codes`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    Action(data = ActionData.OpenCamera),
                    Action(data = ActionData.GoHome),
                    Action(data = ActionData.Screenshot),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Key event action with meta state should include key code in extra key codes`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    Action(
                        data = ActionData.InputKeyEvent(
                            keyCode = KeyEvent.KEYCODE_C,
                            metaState = KeyEvent.META_CTRL_ON,
                        ),
                    ),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_C),
                ),
            ),
        )
    }

    @Test
    fun `Mixed key event and non-key-event actions should only include key codes from key event actions`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(
                    Action(data = ActionData.OpenCamera),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X),
                    Action(data = ActionData.GoHome),
                    buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_Y),
                    Action(data = ActionData.Screenshot),
                ),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(
                        KeyEvent.KEYCODE_BUTTON_X,
                        KeyEvent.KEYCODE_BUTTON_Y,
                    ),
                ),
            ),
        )
    }

    // ==================== DEVICE HANDLING EDGE CASES ====================

    @Test
    fun `Disabled key map should not produce grab requests`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
                isEnabled = false,
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(grabRequests, empty())
    }

    @Test
    fun `Mix of enabled and disabled key maps should only grab for enabled ones`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
                isEnabled = true,
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.GoHome)),
                isEnabled = false,
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    @Test
    fun `Disabled key map with key event actions should not contribute extra key codes`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X)),
                isEnabled = true,
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_Y)),
                isEnabled = false,
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
        )
    }

    // ==================== EMPTY/NULL AND DUPLICATE HANDLING ====================

    @Test
    fun `Key map with empty trigger keys should not produce grab requests`() {
        loadKeyMaps(
            KeyMap(
                trigger = Trigger(keys = emptyList()),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(grabRequests, empty())
    }

    @Test
    fun `Same extra key code from multiple key maps on same device should not duplicate`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X)),
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(buildKeyEventAction(KeyEvent.KEYCODE_BUTTON_X)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = intArrayOf(KeyEvent.KEYCODE_BUTTON_X),
                ),
            ),
        )
    }

    @Test
    fun `All key maps disabled should produce empty grab requests`() {
        loadKeyMaps(
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
                isEnabled = false,
            ),
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE_2,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.GoHome)),
                isEnabled = false,
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(grabRequests, empty())
    }

    @Test
    fun `Large number of key maps should correctly aggregate grab requests`() {
        val keyMaps = (0 until 10).map { index ->
            KeyMap(
                trigger = singleKeyTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A + index,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A + index,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(buildKeyEventAction(KeyEvent.KEYCODE_0 + index)),
            )
        }
        loadKeyMaps(*keyMaps.toTypedArray())

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        val expectedExtraKeyCodes = (0 until 10).map { KeyEvent.KEYCODE_0 + it }.toIntArray()

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    extraKeyCodes = expectedExtraKeyCodes,
                ),
            ),
        )
    }

    @Test
    fun `Parallel trigger with multiple keys on same device should grab once`() {
        loadKeyMaps(
            KeyMap(
                trigger = parallelTrigger(
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_A,
                        keyCode = KeyEvent.KEYCODE_BUTTON_A,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_B,
                        keyCode = KeyEvent.KEYCODE_BUTTON_B,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                    EvdevTriggerKey(
                        scanCode = Scancode.BTN_X,
                        keyCode = KeyEvent.KEYCODE_BUTTON_X,
                        clickType = ClickType.SHORT_PRESS,
                        device = FAKE_CONTROLLER_EVDEV_DEVICE,
                    ),
                ),
                actionList = listOf(Action(data = ActionData.OpenCamera)),
            ),
        )

        val grabRequests = KeyMapDetectionController.getEvdevGrabRequests(algorithm)

        assertThat(
            grabRequests,
            contains(
                GrabTargetKeyCode(
                    name = FAKE_CONTROLLER_EVDEV_DEVICE.name,
                    bus = FAKE_CONTROLLER_EVDEV_DEVICE.bus,
                    vendor = FAKE_CONTROLLER_EVDEV_DEVICE.vendor,
                    product = FAKE_CONTROLLER_EVDEV_DEVICE.product,
                    extraKeyCodes = intArrayOf(),
                ),
            ),
        )
    }

    private fun buildKeyEventAction(keyCode: Int): Action {
        return Action(
            data = ActionData.InputKeyEvent(keyCode = keyCode),
        )
    }

    private fun loadKeyMaps(vararg keyMap: KeyMap) {
        val models = listOf(*keyMap).map { DetectKeyMapModel(it) }
        algorithm.loadKeyMaps(models)
    }
}
