package com.zodiactap.mapper.api

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.hilt.android.AndroidEntryPoint
import com.zodiactap.mapper.base.keymaps.TriggerKeyMapEvent
import com.zodiactap.mapper.system.accessibility.AccessibilityServiceAdapter
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// DON'T MOVE THIS CLASS TO A DIFFERENT PACKAGE BECAUSE IT BREAKS THE API
@AndroidEntryPoint
class TriggerKeyMapsBroadcastReceiver : BroadcastReceiver() {

    @Inject
    lateinit var serviceAdapter: AccessibilityServiceAdapter

    @Inject
    lateinit var coroutineScope: CoroutineScope

    override fun onReceive(context: Context?, intent: Intent?) {
        context ?: return
        intent ?: return

        when (intent.action) {
            Api.ACTION_TRIGGER_KEYMAP_BY_UID -> {
                intent.getStringExtra(Api.EXTRA_KEYMAP_ID)?.let { uid ->
                    coroutineScope.launch {
                        serviceAdapter.send(TriggerKeyMapEvent(uid))
                    }
                }
            }
        }
    }
}
